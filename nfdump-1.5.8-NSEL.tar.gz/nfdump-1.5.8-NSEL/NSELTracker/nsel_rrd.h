/* Copyright : Most of the code for RRD handling has been taken from nftrack plugin 
 *       developed by Author: peter
 *   By issuing the above, i credit the code for NSEL RRD to Peter
 */





int CreateRRDB (char *path, time_t when);

int RRD_StoreDataRow(char *path, char *iso_time,data_row_summary *row_sum, data_row *rowProt);

data_row_summary *RRD_GetDataRow(char *path, time_t when);

time_t	RRD_LastUpdate(char *path);

time_t  RRD_First(char *path);

time_t ISO2UNIX(char *tstring);
