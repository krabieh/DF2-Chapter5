/*  This code is made available as part of BSD Lincense
 *  Please refer to BSDLicense.txt for more information 
 *  Some of the functionality implemented in here is 
 *  taken from PortTrackerPlugin implemented by peter.
 *  (peter.haag@switch.ch) 
 *  nselstat: Deals with flow context information building
 *             and RRDB Summary Stats updation
 *  $Author: Suhas$
 *
 *  $Id: nselstat.c 02 2008-07-24 12:00:00Z Suhas$
 *
 *  $LastChangedRevision: 01 $
 *	
 */

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <syslog.h>
#include <stdlib.h>

#ifdef HAVE_STDINT_H
#include <stdint.h>
#endif

#include "rbtree.h"
#include "nfdump.h"
#include "nffile.h"
#include "nfnet.h"
#include "netflow_v5_v7.h"
#include "nf_common.h"
#include "util.h"
#include "panonymizer.h"
#include "nselstat.h"
#include "nftrack_stat.h"



#define STATFILE "nseld.stat"
#define MaxMemBlocks	256
#define MAX_FLOWS      2000000 // wastage of memory. but helps in effcient indexing! 
static FlowTableRecord_t  **denialIndex; 
static FlowTableRecord_t  **flowList; // this list holds indexes to all flows that were left open/
uint64_t denIdx=0;
uint64_t denIdx_max = MAX_FLOWS;
uint64_t flowIdx=0;
uint64_t flowIdx_max = MAX_FLOWS;
uint64_t numFlows=0;
uint64_t igncnt=0;
int debug=0;
// needed for every RRDB updated

typedef struct stat_header_s {
	uint16_t version;
        int 	av_num;
	time_t when;
}stat_header_t;

/* function prototypes */

static inline FlowTableRecord_t *hash_lookup_FlowTable(uint32_t *index_cache, master_record_t *flow_record);

static inline FlowTableRecord_t *hash_insert_FlowTable(uint32_t index_cache, master_record_t *flow_record);

static void Expand_FlowTable_Blocks(void);

static void Expand_Record_Table(FlowTableRecord_t ***list, uint64_t *max_index);

/* locals */
#ifndef __SUNPRO_C
static 
#endif
hash_FlowTable *FlowTable;

#define mix64(a,b,c) \
{ \
	a=a-b;  a=a-c;  a=a^(c>>43); \
	b=b-c;  b=b-a;  b=b^(a<<9); \
	c=c-a;  c=c-b;  c=c^(b>>8); \
	a=a-b;  a=a-c;  a=a^(c>>38); \
	b=b-c;  b=b-a;  b=b^(a<<23); \
	c=c-a;  c=c-b;  c=c^(b>>5); \
	a=a-b;  a=a-c;  a=a^(c>>35); \
	b=b-c;  b=b-a;  b=b^(a<<49); \
	c=c-a;  c=c-b;  c=c^(b>>11); \
	a=a-b;  a=a-c;  a=a^(c>>12); \
	b=b-c;  b=b-a;  b=b^(a<<18); \
	c=c-a;  c=c-b;  c=c^(b>>22); \
}

#define mix32(a,b,c) { \
	    a -= b; a -= c; a ^= (c>>13); \
	    b -= c; b -= a; b ^= (a<<8); \
	    c -= a; c -= b; c ^= (b>>13); \
	    a -= b; a -= c; a ^= (c>>12);  \
	    b -= c; b -= a; b ^= (a<<16); \
	    c -= a; c -= b; c ^= (b>>5); \
	    a -= b; a -= c; a ^= (c>>3);  \
	    b -= c; b -= a; b ^= (a<<10); \
	    c -= a; c -= b; c ^= (b>>15); \
}

/* Functions */

/* This function allocates momory for the first time
 * when the binary is run. Later memory allocations
 * if needed are done through Expansion function
*/
int Init_FlowTable(uint16_t NumBits, uint32_t Prealloc) {
uint32_t maxindex;
	if(debug)
	printf("\n Flow Table init called with Numbits %u and Prealloc %u",NumBits,Prealloc);
	if ( NumBits == 0 || NumBits > 31 ) {
		fprintf(stderr, "Numbits outside 1..31\n");
		exit(255);
	}
	// allocate memory for flow list indexes

	FlowTable = (hash_FlowTable *)malloc(sizeof(hash_FlowTable));
	if ( !FlowTable ) {
		perror("malloc() failed.\n");
		exit(255);
	}
	denialIndex = (FlowTableRecord_t **)malloc(denIdx_max * sizeof(void *));
	flowList = (FlowTableRecord_t **)malloc(flowIdx_max * sizeof(void *));
	if ( !denialIndex || !flowList ) {
		perror("malloc() failed.\n");
		exit(255);
	}

	maxindex = (1 << NumBits);
	FlowTable->IndexMask   = maxindex -1;
	FlowTable->NumBits     = NumBits;
	FlowTable->Prealloc    = Prealloc;
	FlowTable->bucket	  = (FlowTableRecord_t **)calloc(maxindex, sizeof(FlowTableRecord_t *));
	if ( !FlowTable->bucket ) {
		perror("Can't allocate memory");
		return 0;
	}
	FlowTable->memblock = (FlowTableRecord_t **)calloc(MaxMemBlocks, sizeof(FlowTableRecord_t *));
	if ( !FlowTable->memblock ) {
		perror("Can't allocate memory");
		return 0;
	}
	FlowTable->memblock[0] = (FlowTableRecord_t *)calloc(Prealloc, sizeof(FlowTableRecord_t));
	FlowTable->NumBlocks = 1;
	FlowTable->MaxBlocks = MaxMemBlocks;
	FlowTable->NextBlock = 0;
	FlowTable->NextElem  = 0;
	

	return 1;

} // End of Init_FlowTable

/* Free the memory allocated to hash tables */

void Dispose_Tables(int flow_stat) {
unsigned int i;

	if ( flow_stat ) {
		free((void *)FlowTable->bucket);
		for ( i=0; i<FlowTable->NumBlocks; i++ ) 
			free((void *)FlowTable->memblock[i]);
		free((void *)FlowTable->memblock);
	}


} // End of Dispose_Tables


/* Hash lookup is done based on
 * src/dest ip, src/dest port
 * for create and teardown events
 * walkthrough the collision list is done
 * based on NFC 
*/

static inline FlowTableRecord_t *hash_lookup_FlowTable(uint32_t *index_cache, master_record_t *flow_record) {
// uint64_t			index, a1, a2;
uint32_t			index, a1, a2, randN;
FlowTableRecord_t	*record;
	randN = rand();
	index = (uint32_t)flow_record->srcport << 16 | (uint32_t)flow_record->dstport;
	a1 = flow_record->v4.srcaddr;
	a2 = flow_record->v4.dstaddr;
	mix32(a1, a2, index);
	// a1 = flow_record->v6.srcaddr[1];
	// a2 = flow_record->v6.dstaddr[1];
	// mix64(a1, a2, index);
	if(debug)
	printf("\n Calculating index using src port -> %u , dst port --> %u , v4.srcaddr -> %u , v4.dstaddr --> %u",flow_record->srcport,flow_record->dstport,flow_record->v4.srcaddr,flow_record->v4.dstaddr);
	//index = (randN ^ ( index >> ( 32 - FlowTable->NumBits ))) & FlowTable->IndexMask;
	index = (( index >> ( 32 - FlowTable->NumBits ))) & FlowTable->IndexMask;
	if(debug)
	printf("\n index calcu is %d", index);
	*index_cache = index;

	if ( FlowTable->bucket[index] == NULL )
		return NULL;

	record = FlowTable->bucket[index];
	while ( record ) {
		if ( record->srcport == flow_record->srcport && record->dstport == flow_record->dstport &&
			record->ip.v6.srcaddr[1] == flow_record->v6.srcaddr[1] && record->ip.v6.dstaddr[1] == flow_record->v6.dstaddr[1] && 
			record->ip.v6.srcaddr[0] == flow_record->v6.srcaddr[0] && record->ip.v6.dstaddr[0] == flow_record->v6.dstaddr[0] 
			)
			return record;
		record = record->next;
	}
	return NULL;

} // End of hash_lookup_FlowTable

/* Function to increase the hash table if the Max MemBlocks is > 255 */

static void Expand_FlowTable_Blocks(void) {
	if ( FlowTable->NumBlocks >= FlowTable->MaxBlocks ) {
		FlowTable->MaxBlocks += MaxMemBlocks;
		FlowTable->memblock = (FlowTableRecord_t **)realloc(FlowTable->memblock,
						FlowTable->MaxBlocks * sizeof(FlowTableRecord_t *));
                printf(" Flow Table Mem blocks is %d Max Mem Blocks is %d ",FlowTable->NumBlocks,MaxMemBlocks);

		if ( !FlowTable->memblock ) {
			perror("Expand_FlowTable_Blocks Memory error");
			exit(250);
		}
	}
	FlowTable->memblock[FlowTable->NumBlocks] = 
			(FlowTableRecord_t *)calloc(FlowTable->Prealloc, sizeof(FlowTableRecord_t));

	if ( !FlowTable->memblock[FlowTable->NumBlocks] ) {
		perror("Expand_FlowTable_Blocks Memory error");
		exit(250);
	}
	FlowTable->NextBlock = FlowTable->NumBlocks++;
	FlowTable->NextElem  = 0;

} // End of Expand_FlowTable_Blocks

static void Expand_Record_Table(FlowTableRecord_t ***list, uint64_t *max_index) {
uint64_t max = *max_index + MAX_FLOWS;
FlowTableRecord_t *f;

	f = realloc(*list, max);
	if ( !f ) {
		perror("Expand_Record_Table Memory error");
		exit(250);
	}
	*max_index = max;
	*list = (FlowTableRecord_t **)f;

} // End of Expand_Record_Table


/* Events parsed are collected in here to maintain statisitcs 
 * on num completed, denied and open flows 
 * There is a limitation of 2000000 records for now
 * this is thought to be sufficient on
 * our current RAM reqs. This can be increased and efficient
 * ways can be employed to handle the allocations based on
 * dynamic expansion.
*/

inline static FlowTableRecord_t *hash_insert_FlowTable(uint32_t index_cache, master_record_t *flow_record) {
FlowTableRecord_t	*record, *tmpRecord;

	if ( FlowTable->NextElem >= FlowTable->Prealloc )
	{
		Expand_FlowTable_Blocks();
	}

	numFlows++;
	if ( FlowTable->bucket[index_cache] == NULL ){ 
		//syslog(LOG_INFO,"\n First element at index %u ", index_cache);
		record =  &(FlowTable->memblock[FlowTable->NextBlock][FlowTable->NextElem]);
		FlowTable->NextElem++;
		record->next  	= NULL;
		record->srcport = flow_record->srcport;
		record->dstport = flow_record->dstport;
		record->ip.v6.srcaddr[0] = flow_record->v6.srcaddr[0];
		record->ip.v6.srcaddr[1] = flow_record->v6.srcaddr[1];
		record->ip.v6.dstaddr[0] = flow_record->v6.dstaddr[0];
		record->ip.v6.dstaddr[1] = flow_record->v6.dstaddr[1];
		// hash entry is null . new record case
                // only create and denied records are supported in this
                // state to have decently well stats at the end of interval
		// stray term records are ignored in this impln for the
                // same reason.
		if(flow_record->nf9_fw_evt == 1)
		{
			//record the flow state
			// one of the create records. Go thru the list
   			// of possible create events
			record->connId = flow_record->nf_conn_id;
			record->flowState=0;
			if ( flowIdx >= flowIdx_max ) 
				Expand_Record_Table(&flowList, &flowIdx_max);
			flowList[flowIdx++] = record;
			record->indexedAt = flowIdx-1;
			FlowTable->bucket[index_cache] = record;
				
		}
		else if(flow_record->nf9_fw_evt == 3) {
			  record->flowState=2;
			if ( denIdx >= denIdx_max ) 
				Expand_Record_Table(&denialIndex, &denIdx_max);
			denialIndex[denIdx++] = record;
			record->indexedAt = denIdx-1;
			record->connId = 0;
			FlowTable->bucket[index_cache] = record;
		}else if((flow_record->nsel_flags & FLAG_FLOW_TERM) != 0)
		{
			igncnt++;
			return NULL;
		}
	}
	else {
		if(flow_record->nf9_fw_evt  == 2)
		{
			record = FlowTable->bucket[index_cache];
			while(record != NULL)
			{
				if(record->connId == flow_record->nf_conn_id)
				{
					//got matching connid .. yipee
					break;
				}	
					record = record->next;	

			}//while

			if(record == NULL)
			{
				igncnt++;
			  return NULL;
			}
			record->flowState=2;
			
		}else
		{
			// in the collsion case but w/o term event .. 
			// look for create or denied as new record
			record =  &(FlowTable->memblock[FlowTable->NextBlock][FlowTable->NextElem]);
			FlowTable->NextElem++;
			record->next  	= NULL;
			record->srcport = flow_record->srcport;
			record->dstport = flow_record->dstport;
			record->ip.v6.srcaddr[0] = flow_record->v6.srcaddr[0];
			record->ip.v6.srcaddr[1] = flow_record->v6.srcaddr[1];
			record->ip.v6.dstaddr[0] = flow_record->v6.dstaddr[0];
			record->ip.v6.dstaddr[1] = flow_record->v6.dstaddr[1];
			if((flow_record->nsel_flags & MASK_CONN_ID) != 0) {
                record->connId = flow_record->nf_conn_id;
				record->flowState=0;
				if ( flowIdx >= flowIdx_max ) 
					Expand_Record_Table(&flowList, &flowIdx_max);
				flowList[flowIdx++] = record;
				record->indexedAt = flowIdx-1;
			}
			else {
				 record->connId = 0;
				  record->flowState=2;
				if ( denIdx >= denIdx_max ) 
					Expand_Record_Table(&denialIndex, &denIdx_max);
				denialIndex[denIdx++] = record;
				record->indexedAt = denIdx-1;
			}
			tmpRecord = FlowTable->bucket[index_cache];
			// insert the record at the tail of the list
			while(tmpRecord->next != NULL )
				tmpRecord = tmpRecord->next;

			tmpRecord->next = record;
		}
	    }//else
	return record;

} // End of hash_insert_FlowTable

/* This function is called per every read record from nfcapd file */

int AddStat(data_block_header_t *flow_header, master_record_t *flow_record, int flow_stat){
FlowTableRecord_t	*FlowTableRecord;
uint32_t			index_cache; 
	if(debug)
	printf("\n Add Stat : nsel flags %u", flow_record->nsel_flags);

	if ( flow_stat ) {
		FlowTableRecord = hash_lookup_FlowTable(&index_cache, flow_record);
		if ( FlowTableRecord ) {
			FlowTableRecord = hash_insert_FlowTable(index_cache, flow_record);
			if(!FlowTableRecord)
				return 0;

		} else {
			FlowTableRecord = hash_insert_FlowTable(index_cache, flow_record);
			if ( !FlowTableRecord )
				return -1;
		}
	}

	return 0;

} // End of AddStat

/* Updates the counters into stat_record for summary counters */

void* ReportStat() {
FlowTableRecord_t *r;
uint64_t flCnt=0;
data_row_summary  *nselRec = NULL;
uint64_t openCnt=0;
uint64_t i=0;
       
		   nselRec = (data_row_summary*)malloc(sizeof(data_row_summary));
		   if(!nselRec)
		   {
			perror("Memory Allocation Error for nselRec");
			return NULL;
		   }
		  memset(nselRec,0,sizeof(data_row_summary));

            for(i=0; i<flowIdx; i++)
                {
                        if(flowList[i] != NULL)
                                r = (FlowTableRecord_t*)flowList[i];
                        while(r)
                        {
                                if(r->flowState == 0)
                                {
                                        ++openCnt;
                                }else if (r->flowState == 2)
				{
					++flCnt;
				}
                                r = r->next;
                        }
                }

       		//Update RRD related info in NselRecord
      		nselRec->type[0] += openCnt;
	        syslog(LOG_INFO,"openCnt is %ld type 0 cnt %ld",openCnt, nselRec->type[0] );
      		nselRec->type[1] += flCnt;
	        syslog(LOG_INFO,"flowCnt is %ld type 1 cnt %ld",flCnt, nselRec->type[1] );
      		nselRec->type[2] += denIdx;
	        syslog(LOG_INFO,"denCnt is %ld , type 2 cnt %ld", denIdx,nselRec->type[2] );
      		nselRec->type[3] = 0;
      		nselRec->type[4] = 0;
      		nselRec->type[5] = 0;
      		nselRec->type[6] = 0;
	// the other 4 are not being updated for now . Shall do it soon
		return nselRec;
} // End of ReportStat
