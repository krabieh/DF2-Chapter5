/*  This code is made available as part of BSD Lincense
 *  Please refer to BSDLicense.txt for more information
 *  Some of the functionality implemented in here is
 *  taken from PortTrackerPlugin implemented by peter.
 *
 *  nselstat: Deals with flow context information building
 *             and RRDB Summary Stats updation
 *  $Author: Suhas$
 *
 *  $Id: nselstat.c 02 2008-07-24 12:00:00Z Suhas$
 *
 *  $LastChangedRevision: 01 $
 *
 */

/* Definitions */

/*
 * Flow Table
 * In order to aggregate flows or to generate any flow statistics, the flows passed the filter
 * are stored into an internal hash table.
 */

typedef struct FlowTableRecord {
// due to high number of records that should be processed hash entries should be as simple as possible
// since we maintain flow context, we need all the fields on which key is calculated
	struct FlowTableRecord *next;
	uint8_t flowState;
	uint64_t indexedAt;
	uint32_t connId;
	// below is used for key generation
	uint16_t        srcport;
        uint16_t        dstport;
        ip_block_t      ip;
} FlowTableRecord_t;

typedef struct hash_FlowTable {
	/* hash table data */
	uint16_t 			NumBits;		/* width of the hash table */
	uint32_t			IndexMask;		/* Mask which corresponds to NumBits */
	FlowTableRecord_t 	**bucket;		/* Hash entry point: points to elements in the flow block */
	FlowTableRecord_t 	**bucketcache;	/* in case of index collisions, this array points to the last element with that index */

	/* memory management */
	/* memory blocks - containing the flow blocks */
	FlowTableRecord_t	**memblock;		/* array holding all NumBlocks allocated flow blocks */
	uint32_t 			MaxBlocks;		/* Size of memblock array */
	/* flow blocks - containing the flows */
	uint32_t 			NumBlocks;		/* number of allocated flow blocks in memblock array */
	uint32_t 			Prealloc;		/* Number of flow records in each flow block */
	uint32_t			NextBlock;		/* This flow block contains the next free slot for a flow recorrd */
	uint32_t			NextElem;		/* This element in the current flow block is the next free slot */
} hash_FlowTable;



int Init_FlowTable(uint16_t NumBits, uint32_t Prealloc);

void Dispose_Tables(int flow_stat);

int AddStat(data_block_header_t *flow_header, master_record_t *flow_record, int flow_stat);

void* ReportStat(void);

