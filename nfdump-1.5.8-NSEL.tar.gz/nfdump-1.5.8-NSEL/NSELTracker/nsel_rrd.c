/* Copyright:
 *  This code is made available as part of BSD Lincense
 *  Please refer to BSDLicense.txt for more information
 *  Most of the code for RRD handling has been taken from nftrack plugin
 *       developed by Author: peter
 *   By issuing the above, i credit the code for NSEL RRD to Peter
 */

#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <syslog.h>
#include "config.h"

#ifdef HAVE_STDINT_H
#include <stdint.h>
#endif

#include "rrd.h"
#include "nftrack_stat.h"
#include "nsel_rrd.h"

// be sure to update the number 19 if DataSources or Archives count to be increased or decreased
#define MAXBUFF 15 * 19;
#define BUFF_CHECK(num,buffsize) if ( (num) >= (buffsize) ) { \
 fprintf(stderr, "No enough space to create RRD arg\n");	\
 exit(0);	\
}


/* Functions */
/* we just create on RRDB file with following data sources
 * 1: Open Flows
 * 2: Completed Flows
 * 3: Denied Flows
 * 4: Denied_1001
 * 5: Denied_1002
 * 6: Denied_1003
 * 7: Denien_1004
 * 8: TCP Denied_1001
 * 9: TCP Denied_1002
 * 10: TCP Denied_1003
 * 11: TCP Denied_1004
 * 12: UDP Denied_1001
 * 13: UDP Denied_1002
 * 14: UDP Denied_1003
 * 15: UDP Denied_1004 // included but never will be updated
 * 16: ICMP Denied_1001
 * 17: ICMP Denied_1002
 * 18: ICMP Denied_1003
 * 19: ICMP Denied_1004 // included but never will be updated
 * and following RRAs
      1 x 5min =  5 min samples      7 * 288 ( per day ) = 2016 => 7 days
                 24 x 5min =  2 hour samples   60 *  12 ( per day ) = 720  => 60 days
                288 x 5min =  1 day samples   180 *   1 ( per day ) = 180  => 180 days
*/

int  CreateRRDB (char *path, time_t when) {
char *buff, *s, *rrd_arg[1100];
long i, num, buffsize, argc;
char filename[1024];
struct stat statbuf;
int len;
	optind = 0; opterr = 0;
	argc   = 0;

	if ( (stat(path,&statbuf) < 0) || !(statbuf.st_mode & S_IFDIR))
	{
                fprintf(stderr, "No such directory: '%s'\n", path);
		return 0;
	}
        len = snprintf(filename, 1024, "%s/%s", path, "NSEL.rrd");
        if ( len >= 1024 ) {
                fprintf(stderr, "Failed to concat RRD filename: string overflow");
                return 0;
        }

	/* 	
		Create bufferspace for create args:
		19  DS records: each ~ 23 bytes in average +
		3 RRA records + filename + start time => 512 bytes should be more than enough
	 */
	buffsize = 19 * 1024 + 512;
	buff = (char *)malloc(buffsize);
	printf("\n CreateRRDB : Created memory for buffsize : %lu",buffsize);
	if ( !buff ) {
		perror("Memory error!");
		exit(0);
	}

	s = buff;

	unlink(filename);

	rrd_arg[argc++] = "create";
	
	// add DB name
	rrd_arg[argc++] = filename;

	// Add start time
	num = snprintf(s, buffsize, "--start=%ld", when);
	num++;	// include '\0'
	BUFF_CHECK(num,buffsize);
	rrd_arg[argc++] = s;

	buffsize -= num;
	s += num;
	
	/* Add the DS strings */
	for ( i=0; i<19; i++) {
		num = snprintf(s, buffsize, "DS:src%ld:GAUGE:600:0:U", i);
		num++;	// include '\0'
		printf("I: %ld ", i);
		BUFF_CHECK(num,buffsize);
		rrd_arg[argc++] = s;
		buffsize -= num;
		s += num;
	}
	printf(" Created Data Sources in ARGC \n");
	/* 
		RRD DB layout:
	  	  1 x 5min =  5 min samples	 7 * 288 ( per day ) = 2016 => 7 days
	 	 24 x 5min =  2 hour samples   60 *  12 ( per day ) = 720  => 60 days
		288 x 5min =  1 day samples   180 *   1 ( per day ) = 180  => 180 days
	*/

	num = snprintf(s, buffsize, "RRA:AVERAGE:0.5:1:2016");
	num++;	// include '\0'
	BUFF_CHECK(num,buffsize);
	rrd_arg[argc++] = s;

	buffsize -= num;
	s += num;

	num = snprintf(s, buffsize, "RRA:AVERAGE:0.5:24:720");
	num++;	// include '\0'
	BUFF_CHECK(num,buffsize);
	rrd_arg[argc++] = s;

	buffsize -= num;
	s += num;

	num = snprintf(s, buffsize, "RRA:AVERAGE:0.5:288:180");
	num++;	// include '\0'
	BUFF_CHECK(num,buffsize);
	rrd_arg[argc] = s;

	for ( i=0; i<=argc; i++ ) {
		printf("I:%ld %s\n", i, rrd_arg[i]);
	}

	rrd_clear_error();
	if ( ( i=rrd_create(argc, rrd_arg))) {
		fprintf(stderr, "Create DB Error: %ld %s\n", i, rrd_get_error());
		return 0;
	}
return 1;

} // End of CreateRRDB


int RRD_StoreDataRow(char *path, char *iso_time,  data_row_summary *rowSum, data_row *rowProt) {
char 	rrd_filename[1024], *buff, *s;
char	*rrd_arg[10];
time_t	when, frag;
int 	i, j, len, buffsize, argc;
struct stat statbuf;



	buffsize = MAXBUFF;
	buff = (char *)malloc(buffsize);
	if ( !buff ) {
		perror("Memory error!");
		return 0;
	}

	when = ISO2UNIX(iso_time);
	if ( !when ) 
	{
		syslog(LOG_INFO, "\n RRD_StoreDataRow: when is zero");
		return 0;
	}

	// make sure, we are at a 5min boundary
	frag = when % 300;
	if ( frag ) {
		fprintf(stderr, "Round to next timeslot: offset %ld\n", frag);
		when -= frag;
	}

	len = snprintf(rrd_filename, 1024, "%s/%s.rrd", path,"NSEL");
	if ( len >= 1024 ) {
		fprintf(stderr, "Failed to concat RRD filename: string overflow");
        	return 0;
		}
		
	// Check if RRD file exists
	if ( (stat(rrd_filename, &statbuf) < 0 ) || !(statbuf.st_mode & S_IFREG) ) {
		fprintf(stderr, "No such RRD file: '%s'\n", rrd_filename);
		syslog(LOG_INFO," RRD File not found ");
		return 0;
	}

	buffsize = MAXBUFF;
	s = buff;
	/* add time to RRD arg string */
	len = snprintf(s, buffsize, "%ld:", when);
	buffsize -= len;
	s += len;
	/* add port data to RRD arg string */
	for ( i=0; i<7; i++) 
	{
		syslog(LOG_INFO," RRD_StoreData .. Updating the valie %ld \n",rowSum->type[i]);
       		  len = snprintf(s, buffsize, "%llu:", rowSum->type[i]);
       		 if ( len >= buffsize ) {
       		       fprintf(stderr, "No enough space to create RRD arg\n");
			syslog(LOG_INFO," RRD_StoreData : No mem ");
		         return 0;
       	   }
	      buffsize -= (len);
	      s += (len);
	}
		printf("\n Storing Prot Specific records now ");
	for(i=0;i<3;i++)
	{
		for(j=0;j<4;j++)
		{
		syslog(LOG_INFO,"RRD_StoreData .. Updating the value on protocol  %ld",rowProt->proto[i].type[j]);
       		  len = snprintf(s, buffsize, "%llu:", rowProt->proto[i].type[j]);
       		 if ( len >= buffsize ) {
       		       fprintf(stderr, "No enough space to create RRD arg\n");
			syslog(LOG_INFO," RRD_StoreData : No mem ");
		         return 0;
	       	   }
	      buffsize -= len;
	      s += len;

		}
	}	



	s--;
	*s = '\0';

	// Create arg vector
	argc = 0;
	rrd_arg[argc++] = "update";
	rrd_arg[argc++] = rrd_filename;
	rrd_arg[argc++] = buff;
	rrd_arg[argc]   = NULL;
	optind = 0; opterr = 0;

	 for ( i=0; i<=argc; i++ ) {
                syslog(LOG_INFO,"I:%ld %s\n", i, rrd_arg[i]);
        }
	rrd_clear_error();
	if ( ( i=rrd_update(argc, rrd_arg))) {
		syslog(LOG_INFO,"RRD Store , insert error \n");
		syslog(LOG_INFO, "RRD: %s Insert Error: %d %s\n", rrd_filename, i, rrd_get_error());
	}

	printf("\n soooer");
	return 1;
} // End of RRD_StoreDataRow

data_row_summary *RRD_GetDataRow(char *path, time_t when) {
time_t	last, frag;
struct tm * t1, *t2;
struct stat statbuf;
char 	datestr1[64] , datestr2[64], rrd_filename[1024];
char	*rrd_arg[10];
char 	**ds_namv;
int 	ret, i, j, len, argc;
unsigned long step, ds_cnt, pnum;
data_row_summary	*row;
rrd_value_t   *data;
uint64_t      dummy;

	data = NULL;
	j = 0;
	syslog(LOG_INFO,"RRD_GetDataRow : time input is %s", ctime(&when));
	frag = when % 300;
	syslog(LOG_INFO,"RRD_GetDataRow : frag calc is %s", ctime(&frag));
	if ( frag ) {
		fprintf(stderr, "Round to next timeslot: offset %ld\n", frag);
		when -= frag;
	}
	syslog(LOG_INFO,"RRD_GetDataRow : frag calc is %s", ctime(&frag));

	last = RRD_LastUpdate(path);
	
	syslog(LOG_INFO," In RRD_GetDataRow , last update time is %s", ctime(&last));
	syslog(LOG_INFO," In RRD_GetDataRow , last update in int  %d", last);
	if ( when > last ) {
		t1 = localtime(&when);
		strftime(datestr1, 63, "%b %d %Y %T", t1);

		t2 = localtime(&last);
		strftime(datestr2, 63, "%b %d %Y %T", t2);

		fprintf(stderr, "Error get data: Requested time slot '%s' later then last available time slot '%s'\n",
			datestr1, datestr2);
		syslog(LOG_INFO,"\n in when > last check");

		return NULL;
	}

	row = (data_row_summary *)calloc(1, sizeof(data_row_summary));
	if ( !row ) {
		perror("Memory allocation error");
		return NULL;
	}
	
	len = snprintf(datestr1, 64, "--start=%ld", when);
	if ( len >= 64 ) {
		fprintf(stderr, "String overflow --start\n");
		free(row);
		return NULL;
	}
	len = snprintf(datestr2, 64, "--end=%ld", when);
	if ( len >= 64 ) {
		fprintf(stderr, "String overflow --end\n");
		free(row);
		return NULL;
	}

	len = snprintf(rrd_filename, 1024, "%s/%s.rrd", path,"NSEL");
	if ( len >= 1024 ) {
		fprintf(stderr, "Failed to concat RRD filename: string overflow");
		free(row);
		return NULL;
	}
	syslog(LOG_INFO,"RRD_GetDataRow , rrd file is %s",rrd_filename);
	// Check if RRD file exists
	if ( (stat(rrd_filename, &statbuf) < 0 ) || !(statbuf.st_mode & S_IFREG) ) {
		fprintf(stderr, "No such RRD file: '%s'\n", rrd_filename);
		free(row);
		return NULL;
	}
	// Create arg vector
	argc = 0;
	rrd_arg[argc++] = "fetch";
	rrd_arg[argc++] = rrd_filename;
	rrd_arg[argc++] = "AVERAGE";
	rrd_arg[argc++] = datestr1;
	rrd_arg[argc++] = datestr2;
	rrd_arg[argc]   = NULL;
			
	 for ( i=0; i<=argc; i++ ) {
                syslog(LOG_INFO,"I:%ld %s\n", i, rrd_arg[i]);
        }
	optind = 0; opterr = 0;
	rrd_clear_error();
	if ( ( ret=rrd_fetch(argc, rrd_arg, &when, &when, &step, &ds_cnt, &ds_namv, &data))) {
			fprintf(stderr, "RRD: %s Fetch Error: %d %s\n", rrd_filename, ret, rrd_get_error());
			syslog(LOG_INFO,"RRD FETCH !!: %s",rrd_get_error());
	}
/*
	if ( ds_cnt != 7 ) {
	syslog(LOG_INFO,"RRD_GetDataRow , fetch error %s \n",rrd_get_error());
	syslog(LOG_INFO, "RRD: %s Fetch Error: Short read: Expected 1024 records got %lu\n", 
					rrd_filename, ds_cnt);
		free(row);
		return NULL;
	}
*/

	for ( i=0; i<7; i++) {
		pnum = ( j << 10 ) + i;
		dummy = data[0];
		syslog(LOG_INFO,"\n RRD_GetDataRow : row->type[%d] is %ld : ",i,dummy);
		row->type[i]= dummy;
		}

	free(ds_namv);
	free(data);


	return row;

} // End of RRD_GetDataRow

time_t	RRD_LastUpdate(char *path) {
struct stat statbuf;
char 	rrd_filename[1024];
char	*rrd_arg[10];
time_t	when;
int 	len, argc;

	// Get timestamp from the first file
	len = snprintf(rrd_filename, 1024, "%s/%s.rrd", path, "NSEL");
	if ( len >= 1024 ) {
		fprintf(stderr, "Failed to concat RRD filename: string overflow");
		return 0;
	}
		
	// Check if RRD file exists
	if ( (stat(rrd_filename, &statbuf) < 0 ) || !(statbuf.st_mode & S_IFREG) ) {
		fprintf(stderr, "RRD files not found in '%s'\n", path);
		return 0;
	}

	argc = 0;
	rrd_arg[argc++] = "last";
	rrd_arg[argc++] = rrd_filename;
	rrd_arg[argc]   = NULL;

	when = rrd_last(argc, rrd_arg);
	
	return when;

} // End of RRD_LastUpdate

