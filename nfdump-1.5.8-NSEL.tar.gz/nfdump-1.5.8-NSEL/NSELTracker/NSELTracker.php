<?php

$type  = array ( 'open', 'complete', 'denied' );

$FlowDisplayOrder = array (
        'Open Flows', 'Completed Flows', 'Denied Flows'
);

$DeniedFlowDisplayOrder = array (
	'Denied by Ingress Acl', 'Denied by Egress Acl','Conn to Ifc Service denied', '   1st Pkt Not Tcp Syn'
); 
$DenType = array('den_1001', 'den_1002', 'den_1003', 'den_1004');


$NselTracker_WinSizeLabels = array ( '12 Hours', '1 day', '2 days', '4 days', '1 week', '2 weeks' );
$NselTracker_WinSizeFactor = array ( 0.5       ,  1     ,  2      ,  4      ,  7      , 14);
$NselTracker_DumpOpts = array ('Open Flows' , ' Completed Flows' , ' Denied Flows');
$NselTracker_LimitOpts = array (20,30,50,100,150,200,1000,2000,5000,10000);
$shudRun = 1;


function GetTime($plugin_id)
{
	$opts = array();
	$out_list = nfsend_query('NSELTracker::get-timestamp',$opts,0);
	if(!is_array($out_list)){
		SetMessage('error',"Cannot read the time stamp ");
		return FALSE;
	}

	$time = $out_list['when'];
	$timeinfo= array();
	$timeinfo[] = array_shift($time);
	return $timeinfo;

}# End of GetTime


function DisplayGraph($plugin_id,$timeInfo) {
 global $self;
 global $type;
 global $FlowDisplayOrder;
 global $NselTracker_WinSizeLabels;
 global $NselTracker_WinSizeFactor;
 global $NselTracker_DumpOpts;
 global $NselTracker_LimitOpts;
 global $DenType;
 global $DeniedFlowDisplayOrder;
 $tend = $timeInfo[0];
	//print " SIZE: $0_wsize\n";
        // factor how many days ( 86400s ) back this window scale 'wsize'  relates
        $tstart = $tend - $NselTracker_WinSizeFactor[$_SESSION["${plugin_id}_wsize"]] * 86400;
        //$tstart = $tend - 86400;
	
        #print "\n NselTracker_WinSizeFactor --> $NselTracker_WinSizeFactor[$_SESSION["${plugin_id}_wsize"]] "; 
        $logscale               = $_SESSION["${plugin_id}_logscale"];
        $stacked                = $_SESSION["${plugin_id}_stacked"];
        $maingraph              = $_SESSION["${plugin_id}_graph"];
        $maintypeindex  = $maingraph;
	//print "<h1> in grpah </h1>";

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta content="text/html; charset=ISO-8859-1"
 http-equiv="content-type">
  <title>test</title>
</head>
<body>

<table style="text-align: left;" border="0" cellpadding="3"
 cellspacing="2">
  <tbody>
    <tr>
      <td>
      <table style="text-align: left;" border="0" cellpadding="0" cellspacing="3">
        <tbody>
          <tr>
<?php
             for ( $i=0; $i < count($FlowDisplayOrder); $i++ ) {
                    $label = $FlowDisplayOrder[$i];
                    print "<td>";
                    print $label;
                    print "</td>\n";
                }
                   print "</tr>\n";
                   print "<tr>\n";

            for ( $i=0; $i < count($FlowDisplayOrder); $i++ ) {
                $typeindex  = $i ;
                $g_id = $i;

                // tcp   flows 0        0     1116495000 1116581400 '22 445 135 1433' '80 143'

                print "<td>";
	
		$arg = $type[$typeindex] . " $logscale $stacked 0 $tstart $tend";
                $arg = urlencode($arg);
		
		 $label = "Flow" . '-' . $type[$typeindex];
                print "<a href='$self?${plugin_id}_graph=$g_id'> " .
                      "<img src=rrdgraph.php?cmd=NSELTracker::get-graph&profile=./live&arg=$arg border='0' width='165' height='81' alt='$label'></a>\n";


                print "</td>\n";
            }
                   print "</tr>\n";
?>
        </tbody>
      </table>
      </td>
    </tr>

    <tr>
<td style="vertical-align: bottom;">
            <table>
        <tbody>
                <tr>
<?php
  print "UDP\n";
	for ( $i=0; $i < count($DeniedFlowDisplayOrder)-1; $i++ ) {
                    $label = $DeniedFlowDisplayOrder[$i];
                    print "<td>";
                    print $label;
                    print "</td>\n";
                }
                   print "</tr>\n";
                   print "<tr>\n";

            for ( $i=0; $i < count($DeniedFlowDisplayOrder)-1; $i++ ) {
                $typeindex  = $i ;
                $g_id = $i+3;


                print "<td>";

                $arg = "udp ".$DenType[$typeindex] . " $logscale $stacked 0 $tstart $tend";
                $arg = urlencode($arg);

                 $label = "UDP Flow" . '-' . $DenType[$typeindex];
                print "<a href='$self?${plugin_id}_graph=$g_id'> " .
                      "<img src=rrdgraph.php?cmd=NSELTracker::get-prot-graph&profile=./live&arg=$arg border='0' width='165' height='81' alt='$label'></a>\n";


                print "</td>\n";
            }
        print "</tr>\n";
?>
</tbody>
</table>
</td>
</tr>

    <tr>
<td style="vertical-align: bottom;">
            <table>
        <tbody>
                <tr>
<?php
  print "TCP\n";
        for ( $i=0; $i < count($DeniedFlowDisplayOrder); $i++ ) {
                    $label = $DeniedFlowDisplayOrder[$i];
                    print "<td>";
                    print $label;
                    print "</td>\n";
                }
                   print "</tr>\n";
                   print "<tr>\n";
            for ( $i=0; $i < count($DeniedFlowDisplayOrder); $i++ ) {
                $typeindex  = $i ;
	    	$g_id = $g_id+1;

                print "<td>";

                $arg = "tcp ".$DenType[$typeindex] . " $logscale $stacked 0 $tstart $tend";
                $arg = urlencode($arg);

                 $label = "TCP Flow" . '-' . $DenType[$typeindex];
                print "<a href='$self?${plugin_id}_graph=$g_id'> " .
                      "<img src=rrdgraph.php?cmd=NSELTracker::get-prot-graph&profile=./live&arg=$arg border='0' width='165' heig
ht='81' alt='$label'></a>\n";


                print "</td>\n";
            }
        print "</tr>\n";
?>
</tbody>
</table>
</td>
</tr>

    <tr>
<td style="vertical-align: bottom;">
            <table>
        <tbody>
                <tr>
<?php
	print "ICMP\n";
        for ( $i=0; $i < count($DeniedFlowDisplayOrder) -1 ; $i++ ) {
                    $label = $DeniedFlowDisplayOrder[$i];
                    print "<td>";
                    print $label;
                    print "</td>\n";
                }
                   print "</tr>\n";
                   print "<tr>\n";

            for ( $i=0; $i < count($DeniedFlowDisplayOrder)-1; $i++ ) {
                $typeindex  = $i ;
                $g_id = $g_id+1;


                print "<td>";

                $arg = "icmp ".$DenType[$typeindex] . " $logscale $stacked 0 $tstart $tend";
                $arg = urlencode($arg);

                 $label = "ICMP Flow*" . '-' . $DenType[$typeindex];
                print "<a href='$self?${plugin_id}_graph=$g_id'> " .
                      "<img src=rrdgraph.php?cmd=NSELTracker::get-prot-graph&profile=./live&arg=$arg border='0' width='165' heig
ht='81' alt='$label'></a>\n";


                print "</td>\n";
            }
        print "</tr>\n";
?>
</tbody>
</table>
</td>
</tr>



    <tr>
<td style="vertical-align: bottom;">
            <table>
                <tr>
                    <td>
<?php
		if($maintypeindex > 2)
		{
			if($maintypeindex == 3 || $maintypeindex ==4 || $maintypeindex == 5)
			{
				$arg = "udp ".$DenType[$maintypeindex-3]. " $logscale $stacked 0 $tstart $tend";
                		$arg = urlencode($arg);
 				$label = "UDP Flow" . '-' . $DenType[$maintypeindex-3];
			}else if($maintypeindex == 6|| $maintypeindex == 7 ||$maintypeindex == 8 || $maintypeindex ==9)
			{
			
				$arg = "tcp ".$DenType[$maintypeindex-6]. " $logscale $stacked 0 $tstart $tend";
                		$arg = urlencode($arg);
 				$label = "TCP Flow" . '-' . $DenType[$maintypeindex-6];

			}else if ($maintypeindex > 9 && $maintypeindex  < 13)
			{
				$arg = "icmp ".$DenType[$maintypeindex-10]. " $logscale $stacked 0 $tstart $tend";
                		$arg = urlencode($arg);
 				$label = "ICMP Flow" . '-' . $DenType[$maintypeindex-10];

			}
 		print "<img src=rrdgraph.php?cmd=NSELTracker::get-prot-graph&profile=./live&arg=$arg border='0' width='669' height='396' alt='$label'>\n";
		}else
		{
 			$arg = $type[$maintypeindex] . " $logscale $stacked 0 $tstart $tend";
       	        	 $arg = urlencode($arg);
 			$label = "Flow" . '-' . $type[$maintypeindex];
 		print "<img src=rrdgraph.php?cmd=NSELTracker::get-graph&profile=./live&arg=$arg border='0' width='669' height='396' alt='$label'>\n";
		}

?>
      </td>
      
</tr>

<tr>
                    <td>
                    <table style='width:100%;'>
                    <tr>
			<td style='padding-top:0px;'>
	 		<form action="<?php echo $self;?>" method="POST" style="display:inline">Display
                        <select name='<?php echo "${plugin_id}_wsize";?>' onchange='this.form.submit();' size=1>
<?php
                        for ( $i = 0; $i < count($NselTracker_WinSizeLabels); $i++ ) {
                            if ( $i == $_SESSION["${plugin_id}_wsize"] )
				print "<option value='$i' selected >". $NselTracker_WinSizeLabels[$i]."</option>\n";
                            else
				print "<option value='$i'>". $NselTracker_WinSizeLabels[$i]."</option>\n";
                        }
?>
                        </select>

                        </td>
                        <td>
                        Y-axis:
                        <input type="radio" onClick='this.form.submit();' name='<?php echo "${plugin_id}_logscale";?>' value="0"
                        <?php if ( $_SESSION["${plugin_id}_logscale"] == 0 ) print "checked"; ?> >Linear
                        <input type="radio" onClick='this.form.submit();' name='<?php echo "${plugin_id}_logscale";?>' value="1"
                        <?php if ( $_SESSION["${plugin_id}_logscale"] == 1 ) print "checked"; ?> >Log
                        </td>
                        </form>
                    </tr>
		    <tr>
			<td>
			</td>
		    </tr>
		    <tr>

		    </tr>
                    </table>
		  </td>
</tr>
  </tbody>
</table>

</body>
</html>

<?php
}

function Display($plugin_id,$timeInfo) {
	
	 global $self;
 	global $type;
	 global $FlowDisplayOrder;
	 global $NselTracker_WinSizeLabels;
	 global $NselTracker_WinSizeFactor;
	global  $NselTracker_DumpOpts;
	global $NselTracker_LimitOpts;
	$opts = array();
	$tend = $timeInfo[0];
       // $tstart = $tend - $NselTracker_WinSizeFactor[$_SESSION["${plugin_id}_wsize"]] * 86400;
        $tstart = $tend - 300; 
	$dumpType =  $NselTracker_DumpOpts[$_SESSION["${plugin_id}_dopts"]];
	 $opts['tstart'] = $tstart;
	 $opts['tend'] = $tend;
	$opts['dumpType'] = $_SESSION["${plugin_id}_dopts"] ;
	$limit = $NselTracker_LimitOpts[$_SESSION["${plugin_id}_lopts"]] ;

	$opts['limitFlows'] =  $NselTracker_LimitOpts[$_SESSION["${plugin_id}_lopts"]] ;
//	
//	print "\n TSTRAT :  $tstart";
//	print "\n TEND :  $tend";
	print "\n";	
	print "\n";	
	print "\n";	
	print "\n";	
?>
	NSEL DUMP FOR LAST 15 MINUTES : 
<?php
	 print "<div class='flowlist'>\n";
		print "<pre>\n";
		 $out_list = nfsend_query('NSELTracker::run-nseld', $opts, 0);
                if ( !is_array($out_list) ) {
                        SetMessage('error', "Can not read topN list");
                         return FALSE;
                }
		$pattern = '/^A(\s*)([^\s]+)/';
                        $replacement = "$1<a href='#null' onClick='lookup(\"$2\", this, event)' title='lookup $2'>$2</a>";
                        ClearMessages();
                  foreach ( $out_list['nseld'] as $line ) {
                                  	print preg_replace($pattern, $replacement, $line) . "\n";
                                }
		print "</pre>\n";
	print "</div>\n";
?>



<?php
} // End of DisplayTopNPorts


function NSELTracker_ParseInput ($plugin_id) {

global $FlowDisplayOrder;
global $UdpDeniedFlowDisplayOrder;

if ( isset($_GET["${plugin_id}_graph"]) ) {
                $_tmp = $_GET["${plugin_id}_graph"];
                if ( !is_numeric($_tmp) || ($_tmp > 12) || ($_tmp < 0) )
 		{
                        $_SESSION['warning'] = "Can't display graph '$_tmp'";
                } else {
                        $_SESSION["${plugin_id}_graph"] = $_tmp;
                }
        }

        if ( !isset($_SESSION["${plugin_id}_graph"]) ) {
                        $_SESSION["${plugin_id}_graph"] = 0;
        }


        // register 'get-graph' command for rrdgraph.php
        if ( !array_key_exists('rrdgraph_cmds', $_SESSION) ||
                 !array_key_exists('NSELTracker::get-graph', $_SESSION['rrdgraph_cmds'])
 ) {
                $_SESSION['rrdgraph_cmds']['NSELTracker::get-graph'] = 1;
        }
        $_SESSION['rrdgraph_getparams']['profile'] = 1;

        // register 'get-graph' command for rrdgraph.php
        if ( !array_key_exists('rrdgraph_cmds', $_SESSION) ||
                 !array_key_exists('NSELTracker::get-prot-graph', $_SESSION['rrdgraph_cmds'])
 ) {
                $_SESSION['rrdgraph_cmds']['NSELTracker::get-prot-graph'] = 1;
        }
        $_SESSION['rrdgraph_getparams']['profile'] = 1;

	

        // Graph wsize
        if ( isset($_POST["${plugin_id}_wsize"]) ) {
                $_tmp = $_POST["${plugin_id}_wsize"];
                if ( !is_numeric($_tmp) || ($_tmp > 5) || ($_tmp < 0)) {
                        $_SESSION['warning'] = "Invalid Window scale. Defaults to 1 day.";
                        $_SESSION["${plugin_id}_wsize"] = 1;
                } else {
                        $_SESSION["${plugin_id}_wsize"] = $_tmp;
                }
        }
        if ( !isset($_SESSION["${plugin_id}_wsize"]) ) {
                        $_SESSION["${plugin_id}_wsize"] = 1;
        }

        //  Dump Opts
        if ( isset($_POST["${plugin_id}_dopts"]) ) {
                $_tmp = $_POST["${plugin_id}_dopts"];
                        $_SESSION["${plugin_id}_dopts"] = $_tmp;
        }
        if ( !isset($_SESSION["${plugin_id}_dopts"]) ) {
                        $_SESSION["${plugin_id}_dopts"] = 1 ;
        }

   //  Limit Opts
        if ( isset($_POST["${plugin_id}_lopts"]) ) {
                $_tmp = $_POST["${plugin_id}_lopts"];
                        $_SESSION["${plugin_id}_lopts"] = $_tmp;
        }
        if ( !isset($_SESSION["${plugin_id}_lopts"]) ) {
		print "\n SU :  $_tmp";
                        $_SESSION["${plugin_id}_lopts"] = 1 ;
        }

        // Graph Scale
        if ( isset($_POST["${plugin_id}_logscale"]) ) {
                $_tmp = $_POST["${plugin_id}_logscale"];
                if ( !is_numeric($_tmp) || ($_tmp > 1) || ($_tmp < 0)) {
                        $_SESSION['warning'] = "Invalid Graph Scaling. Defaults to linear.";
                        $_SESSION["${plugin_id}_logscale"] = 0;
                } else {
                        $_SESSION["${plugin_id}_logscale"] = $_tmp;
                }
        }
        if ( !isset($_SESSION["${plugin_id}_logscale"]) ) {
                        $_SESSION["${plugin_id}_logscale"] = 0;
        }



       // Stacked Graph
        if ( isset($_POST["${plugin_id}_stacked"]) ) {
                $_tmp = $_POST["${plugin_id}_stacked"];
                if ( !is_numeric($_tmp) || ($_tmp > 1) || ($_tmp < 0)) {
                        $_SESSION['warning'] = "Invalid Graph Scaling. Defaults to linear.";
                        $_SESSION["${plugin_id}_stacked"] = 0;
                } else {
                        $_SESSION["${plugin_id}_stacked"] = $_tmp;
                }
        }
        if ( !isset($_SESSION["${plugin_id}_stacked"]) ) {
                        $_SESSION["${plugin_id}_stacked"] = 0;
        }




}


function NSELTracker_Run($plugin_id) {

	global $FlowDisplayOrder;
  	print "<h3>NSELTracker</h3>\n";
	$timestamp = GetTime($plugin_id);
	if($timestamp == FALSE)
	{
		print "<h3> Error reading time stamp info </h3>\n";
		return;
	}
	$graph=0;	
	DisplayGraph($plugin_id,$timestamp);
//	Display($plugin_id,$timestamp);

} // End of PortTracker_Run

?>
