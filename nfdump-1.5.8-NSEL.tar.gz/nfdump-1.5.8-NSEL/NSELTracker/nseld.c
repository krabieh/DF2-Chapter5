/*  This code is made available as part of BSD Lincense
 *  Please refer to BSDLicense.txt for more information
 *  Some of the functionality implemented in here is
 *  taken from PortTrackerPlugin implemented by peter.
 *  (peter.haag@switch.ch)
 *  nseld : Main Function 
 *  $Author: Suhas$
 *
 *  $Id: nseld.c 02 2008-07-24 12:00:00Z Suhas$
 *
 *  $LastChangedRevision: 01 $
 *
 */

#include "config.h"

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include <errno.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/resource.h>
#include <syslog.h>


#ifdef HAVE_STDINT_H
#include <stdint.h>
#endif

#include "nffile.h"
#include "nfnet.h"
#include "nf_common.h"
#include "netflow_v5_v7.h"
#include "rbtree.h"
#include "nftree.h"
#include "nselstat.h"
#include "nfprof.h"
#include "nseld.h"
#include "ipconv.h"
#include "version.h"
#include "launch.h"
#include "util.h"
#include "flist.h"
#include "panonymizer.h"
#include "nftrack_stat.h"
#include "nsel_rrd.h"
/* hash parameters */
#define HashBits 20
#define NumPrealloc 128000
static uint64_t total_bytes;
static uint64_t total_flows;




/* Local Variables */
static char const *rcsid 		  = "$Id: nseld.c 02 2008-02-22 09:13:12Z suhas$";
static time_t t_first_flow, t_last_flow;
int fd[5];
extern const uint16_t MAGIC;
extern const uint16_t VERSION;


/* exported fuctions */
void LogError(char *format, ...);



static data_row* process_data(int flow_stat,
	printer_t print_header, printer_t print_record, time_t twin_start, time_t twin_end, 
	int dumpType, int tag, int compress);


/* 
 * some modules are needed for daemon code as well as normal stdio code 
 * therefore a generic LogError is defined, which maps in this case
 * to stderr
 */
void LogError(char *format, ...) {
va_list var_args;

	va_start(var_args, format);
	vfprintf(stderr, format, var_args);
	va_end(var_args);

} // End of LogError

// most of the params are not being used. later code versions shall have these things
// cleaned up
static data_row*  process_data(int flow_stat,
	printer_t print_header, printer_t print_record, time_t twin_start, time_t twin_end, 
	int dumpType, int tag, int compress) {
data_block_header_t in_block_header, *out_block_header;					
common_record_t 	*flow_record, *in_buff, *out_buff;
master_record_t		master_record;
void				*writeto;
uint32_t	file_blocks;
int 		i, rfd, fdCnt, done, ret, do_stat;
char 		*string;
int prot_index = 0; 
// storage for data_row for protocol specific denied stats
data_row    *prot_table;

#ifdef COMPAT14
extern int	Format14;
#endif
fdCnt =0;
// debug code shud be removed later
struct tm *timeinfo;
	if(twin_start)
	{
		timeinfo = localtime(&twin_start);
		syslog(LOG_INFO,"\n twin_start time is %s:", asctime(timeinfo));		
	}
	out_block_header = NULL;
	out_buff 		= NULL;
	writeto			= NULL;


	// time window of all processed flows
	t_first_flow = 0x7fffffff;
	t_last_flow  = 0;

	file_blocks  = 0;

	do_stat = flow_stat;

	// Get the first file handle
	rfd = GetNextFile(0, twin_start, twin_end, NULL);
	fd[0] = rfd;
	if ( rfd < 0 ) {
		if ( rfd == FILE_ERROR )
			perror("Can't open input file for reading");
		return NULL;
	}

#ifdef COMPAT14
	if ( Format14 ) 
		fprintf(stderr, "Reading nfdump <= v1.4 old style file format!\n");
#endif

	// allocate buffer suitable for netflow version
	in_buff = (common_record_t *) malloc(BUFFSIZE);

	if ( !in_buff ) {
		perror("Memory allocation error");
		close(rfd);
		return NULL;
	}

      //Allocate memory for prot_table
      prot_table = (data_row*)calloc(1,sizeof(data_row));
      memset((void*) prot_table, 0 , sizeof(data_row));
	done = 0;
	while ( !done ) {
		// get next data block from file
		ret = ReadBlock(rfd, &in_block_header, (void *)in_buff, &string);
		syslog(LOG_INFO,"Got next block from the file with ret %d", ret);
		switch (ret) {
			case NF_CORRUPT:
			case NF_ERROR:
				if ( ret == NF_CORRUPT ) 
					fprintf(stderr, "Skip corrupt data file '%s': '%s'\n",GetCurrentFilename(), string);
				else 
					fprintf(stderr, "Read error in file '%s': %s\n",GetCurrentFilename(), strerror(errno) );
				// fall through - get next file in chain
			case NF_EOF:
				rfd = GetNextFile(rfd, twin_start, twin_end, NULL);
				if ( rfd < 0 ) {
					if ( rfd == NF_ERROR )
						fprintf(stderr, "Read error in file '%s': %s\n",GetCurrentFilename(), strerror(errno) );

					// rfd == EMPTY_LIST
					done = 1;
				} // else continue with next file
				continue;
	
				break; // not really needed
			default:
				// successfully read block
				total_bytes += ret;
		}

		if ( in_block_header.id != DATA_BLOCK_TYPE_1 ) {
			fprintf(stderr, "Can't process block type %u. Skip block.\n", in_block_header.id);
			continue;
		}

		flow_record = in_buff;
		for ( i=0; i < in_block_header.NumBlocks; i++ ) {
			total_flows++;
			ExpandRecord( flow_record, &master_record);

			// Update global time span window
			if ( master_record.first < t_first_flow )
				t_first_flow = master_record.first;
			if ( master_record.last > t_last_flow ) 
				t_last_flow = master_record.last;

			// we need to add this record to the stat hash
			AddStat(&in_block_header, &master_record, flow_stat);
			// Advance pointer by number of bytes for netflow record
			flow_record = (common_record_t *)((pointer_addr_t)flow_record + flow_record->size);	

			// update data_row to each protocol depending on the denied reason
			prot_index = 0; 
                        switch( master_record.prot)
			{
				case 1:
					prot_index = 2;//icmp
					break;
				case 6:
					prot_index = 0; //tcp
					break;
				case 17:
					prot_index = 1;//udp
					break;
			}
			if(master_record.nsel_flags == 16 || master_record.nsel_flags == 32 || master_record.nsel_flags == 64)
			{
				switch(master_record.nf9_fw_ext_evt)
				{
					case 1001:
						prot_table->proto[prot_index].type[0]++;
						
						break;
					case 1002:
						prot_table->proto[prot_index].type[1]++;
						printf("\n Updated count for 1002");
						break;
					case 1003:
						prot_table->proto[prot_index].type[2]++;
						printf("\n Updated count for 1003");
						break;
					case 1004:
						prot_table->proto[prot_index].type[3]++;
						printf("\n Updated count for 1004");
						break;

				}


			}

			}//end for


	} // while
	if ( rfd > 0 ) 
		close(rfd);
	free((void *)in_buff);
	return prot_table;

} // End of process_data


int main( int argc, char **argv ) {
struct stat stat_buff;
char 		*DBdir,*rfile, *Rfile, *Mdirs, *wfile, *ffile, *filter, *tstring, *stat_type;
char		  *record_header;
int 		 ret;
int 		flow_stat,quiet; 
time_t 	      when,t_start, t_end;
int 		dumpOpt,limitflows; 
data_row_summary        *nselRecord,*tmpRec;
data_row *port_table;
char            *timeslot;
char            c;
int  DBInit, AddDB, GenStat, AvStat;

	rfile = Rfile = Mdirs = wfile = ffile = filter = tstring = stat_type = timeslot = DBdir = NULL;
	DBInit = AddDB = GenStat = AvStat = 0;
	t_start = t_end = 0;
	flow_stat       = 0;
	total_bytes		= 0;
	total_flows		= 0;
	dumpOpt 		= 0;
	limitflows		= 0;
	quiet 			= 0;
	record_header 	= "";


	while ((c = getopt(argc, argv, "c:s:l:d:n:pr:t:w:AIM:R:S:E:o")) != EOF) {
		switch (c) {
			case 'I':
				DBInit=1;
				break;
			case 'A':
				AddDB=1;
				break;
			case 'c':
				limitflows = atoi(optarg);
				break;
			case 's':
				quiet=atoi(optarg);
				break;
			case 'l':
				// possible strings include 0 or 1 or 2
				// 0 -> open , 1 -> complete , 2 -> denied
				dumpOpt = atoi(optarg);
				if( dumpOpt > 2 || dumpOpt < 0 )
				{
					fprintf(stderr, "Option -D can take either 0 or 1 or 2. Defaulting to 1\n");
				        dumpOpt = 1;		
				}		
				break;
			case 'd':
				 DBdir = strdup(optarg);
                                ret  = stat(DBdir, &stat_buff);
                                if ( !(stat_buff.st_mode & S_IFDIR) ) {
                                        fprintf(stderr, "No such directory: %s\n", DBdir);
                                        exit(255);
                                }
				break;
			case 'V':
				printf("%s: Version: %s %s\n%s\n",argv[0], nfdump_version, nfdump_date, rcsid);
				exit(0);
				break;
			case 't':
				timeslot = optarg;
				 if ( !ISO2UNIX(timeslot) ) {
                                        exit(255);
                                }
				break;
			case 'r':
				rfile = optarg;
				if ( strcmp(rfile, "-") == 0 )
					rfile = NULL;
				break;
			case 'M':
				Mdirs = strdup(optarg);
				break;
			case 'S':
				t_start = atoi(optarg);
				break;
			case 'E':
				t_end = atoi(optarg);
				break;
			case 'R':
				Rfile = strdup(optarg);
				break;
			case 'w':
				wfile = strdup(optarg);
				break;
			default:
				exit(0);
		}
	}
	if (argc - optind > 1) {
		exit(255);
	} else {
	}
	
	 if ( !DBdir ) {
                fprintf(stderr, "DB directory required\n");
                exit(255);
        }
        InitStat(DBdir);
        if ( DBInit ) {
                when = time(NULL);
                when -= ((when % 300) + 300);
		syslog(LOG_INFO,"Creating RRDB with time as %s", ctime(&when));
		printf("Creating RRDB with time as %s", ctime(&when));
                InitStatFile(when, 288);
                if ( !CreateRRDB(DBdir, when) ) {
                        fprintf(stderr, "Init DBs failed\n");
                        exit(255);
                }
                fprintf(stderr, "Port DBs initialized.\n");
                exit(0);
        }

	flow_stat = 1;
	if ((flow_stat )  && !Init_FlowTable(HashBits, NumPrealloc) )
			exit(250);



	  nselRecord = NULL;
	  tmpRec = NULL;
	  port_table = NULL;
        if ( Mdirs || Rfile || rfile) {
                SetupInputFileSequence(Mdirs, rfile, Rfile);
		port_table = process_data(flow_stat, 0, 0, 0,0 ,0, 0, 0);
		 nselRecord = (data_row_summary*) ReportStat();
                if ( !nselRecord ) {
			syslog(LOG_INFO,": report stat returned null !!");
                        exit(255);
                }
                if ( AddDB ) {
		printf("\n in Add Db ");
                        if ( !timeslot ) {
                               printf( "Timeslot required!\n");
                                exit(255);
                        }
		// now we have both prot_table and nselRec updated with the current 
                // stats

                UpdateStatNsel(nselRecord, ISO2UNIX(timeslot));
                RRD_StoreDataRow(DBdir, timeslot, nselRecord,port_table);
		if(wfile != NULL)
        	{
                    tmpRec = GetStat();
            	if(tmpRec ==  NULL)
           	 {
               	 syslog(LOG_ERR," GetStat returned NULL");
               	 exit(255);
           	 }
            	GenerateDump(tmpRec,wfile);
       	       }

               }
        }

	CloseStat();
	return 0;
}
