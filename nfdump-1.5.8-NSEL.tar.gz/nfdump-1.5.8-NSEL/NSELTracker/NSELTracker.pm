package NSELTracker;

use strict;
use NfSen;
use NfConf;

#
# The plugin may send any messages to syslog
# Do not initialize syslog, as this is done by 
# the main process nfsen-run
use Sys::Syslog;
Sys::Syslog::setlogsock('unix');
  
our $VERSION = 130;


our %cmd_lookup = (
	'run-nseld'	=> \&RunNselD, # this is temporarily not used
	'get-timestamp'     => \&GetTimeStamp,
	'get-graph'     => \&GetGraph,
	'get-prot-graph'     => \&GetProtGraph
);

my ( $nselD, $PROFILEDATADIR );

# important .. this should be in sync with nselD's -d option
my $PORTSDBDIR = "/data/nfsen/nsel";

my $EODATA  = ".\n";

# colors that wil be used 
my @colour = (
        '#ff0000', '#ff8000', '#ffff00', '#80ff00', '#00ff00',
        '#00ff80', '#00ffff', '#0080ff', '#0000ff', '#8000ff',
        '#ff00ff', '#ff0080'
);

sub GetTimeStamp {
	my $socket = shift;
	my $opts =   shift;
	syslog('debug', " Called GetTimeStamp\n" );
        print $socket ".Get Time Stamp\n";
	my $statfile = 'nsel_stat.txt';
	print $socket ".time stamp $PORTSDBDIR/$statfile\n";	
	if(!open STAT,"$PORTSDBDIR/$statfile") {
		print $socket $EODATA;
		print $socket," ERR Open stat file '$PORTSDBDIR/$statfile': $!\n";
		return;

	}

        while(<STAT>)
	{
		chomp;
		print $socket "_when=$_\n";
	}
	 print $socket $EODATA;
        print $socket "OK Command completed\n",

}#End of GetTimeStampInfo


sub GetGraph {
my $socket = shift;
my $opts   = shift;

	# get all arguments:
        # Example:
        # type         logscale light tstart     tend       
        # denied_list  0        0     1116495000 1116581400 
        if ( !exists $$opts{'arg'} ) {
                print $socket $EODATA;
                print $socket "ERR Missing Arguments.\n";
        }
	syslog('debug', "Get Graph Called ");
	my $ARGS = $$opts{'arg'};
        my $type                = shift @$ARGS; # 'open' , 'denied', 'complete' , den_100* types
        my $logscale    	= shift @$ARGS; # 0 or 1
        my $stacked             = shift @$ARGS; # 0 or 1
        my $light               = shift @$ARGS; # 0 or 1
        my $tstart              = shift @$ARGS; # start time - UNIX format
        my $tend                = shift @$ARGS; # end time - UNIX format
	syslog('debug', "Args : $type, $logscale $stacked $light $tstart $tend ");
	 if (  !defined $type || !defined $logscale || !defined $stacked ||
                 !defined $light || !defined $tstart || !defined $tend
                  ) {
		syslog('debug', "returnign due to errors ");
                print $socket $EODATA;
                print $socket "ERR Argument Error.\n";
                return;
        }
	
        my $datestr = scalar localtime($tstart) . " - " . scalar localtime($tend);
        my $title   = "Flow" . " " . ucfirst($type);

        my @DEFS = ();


	 # Compile rrd args
        my @rrdargs = ();
        push @rrdargs, "-";     # output graphics to stdout
        my $rrdfile     = "$PORTSDBDIR/NSEL.rrd";
	syslog('debug', "\n rrd file is $rrdfile");
	# based on type sent corresponding source in DS should be invoked
        if($type eq 'open')
	{
        	push @rrdargs, "DEF:Flow${type}_0=$rrdfile:src0:AVERAGE";
	}elsif($type eq 'complete') 
	{
        	push @rrdargs, "DEF:Flow${type}_1=$rrdfile:src1:AVERAGE";

	}elsif($type eq 'denied')
	{
        	push @rrdargs, "DEF:Flow${type}_2=$rrdfile:src2:AVERAGE";
	}else
	{
		syslog('debug', "type dint match  ");
                print $socket $EODATA;
                print $socket "ERR Argument Error.\n";
                return;

	}

        push @rrdargs, "--start",  "$tstart";
        push @rrdargs, "--end",    "$tend";
        push @rrdargs, "--title",  "$datestr - $title" unless $light;
        push @rrdargs, "--vertical-label", "$title"  unless $light;

        # lin or log graph?
        push @rrdargs, "--logarithmic" if $logscale;
	if ( $light ) {
                push @rrdargs, "-w";
                push @rrdargs, "288";
                push @rrdargs, "-h";
                push @rrdargs, "150";
                push @rrdargs, "--no-legend";   # no legend in small pictures
        } else {
                push @rrdargs, "-w";
                push @rrdargs, "576";
                push @rrdargs, "-h";
                push @rrdargs, "300";
        }
	if($type eq 'open')
	{
		 push @rrdargs, "LINE2:Flow${type}_0$colour[1]:Flow ${type}";

	}elsif($type eq 'complete')
	{
		 push @rrdargs, "LINE2:Flow${type}_1$colour[0]:Flow ${type}";

	}elsif($type eq 'denied')
	{
		 push @rrdargs, "LINE2:Flow${type}_2$colour[8]:Flow ${type}";
	}else
	{
		syslog('debug', "type dint match  ");
                print $socket $EODATA;
                print $socket "ERR Argument Error.\n";
                return;
	}


	my($averages,$xsize,$ysize) = RRDs::graph( @rrdargs );

	my $ERROR;
        if ($ERROR = RRDs::error) {
                print "ERROR: $ERROR\n";
        }
	syslog('debug', "rrd error is $ERROR");

} # End of Get-Graph


sub GetProtGraph {
my $socket = shift;
my $opts   = shift;

	# get all arguments:
        # Example:
        # type         logscale light tstart     tend       
        # denied_list  0        0     1116495000 1116581400 
        if ( !exists $$opts{'arg'} ) {
                print $socket $EODATA;
                print $socket "ERR Missing Arguments.\n";
        }
	syslog('debug', "Get Graph Called ");
	my $ARGS = $$opts{'arg'};
	my $proto                = shift @$ARGS; # 'tcp, 'udp', 'icmp'
        my $type                = shift @$ARGS; # 'open' , 'denied', 'complete' , den_100* types
        my $logscale    	= shift @$ARGS; # 0 or 1
        my $stacked             = shift @$ARGS; # 0 or 1
        my $light               = shift @$ARGS; # 0 or 1
        my $tstart              = shift @$ARGS; # start time - UNIX format
        my $tend                = shift @$ARGS; # end time - UNIX format
	syslog('debug', "Args : $type, $logscale $stacked $light $tstart $tend ");
	 if (  !defined $type || !defined $logscale || !defined $stacked ||
                 !defined $light || !defined $tstart || !defined $tend
                  ) {
		syslog('debug', "returnign due to errors ");
                print $socket $EODATA;
                print $socket "ERR Argument Error.\n";
                return;
        }
	
        my $datestr = scalar localtime($tstart) . " - " . scalar localtime($tend);
        my $title   = "Flow"."_".ucfirst($proto) . " " . ucfirst($type);

        my @DEFS = ();


	 # Compile rrd args
        my @rrdargs = ();
        push @rrdargs, "-";     # output graphics to stdout
        my $rrdfile     = "$PORTSDBDIR/NSEL.rrd";
	syslog('debug', "\n rrd file is $rrdfile");
	# based on type sent corresponding source in DS should be invoked
	syslog('debug', "\n proto is $proto and type is $type");

	if($proto eq 'udp')
	{
       		 if($type eq 'den_1001')
			{
        			push @rrdargs, "DEF:Flow${proto}_${type}_0=$rrdfile:src11:AVERAGE";
			}elsif($type eq 'den_1002') 
			{
        			push @rrdargs, "DEF:Flow${proto}_${type}_1=$rrdfile:src12:AVERAGE";

			}elsif($type eq 'den_1003')
			{
        			push @rrdargs, "DEF:Flow${proto}_${type}_2=$rrdfile:src13:AVERAGE";

			}else
			{
				syslog('debug', "type dint match  ");
               				 print $socket $EODATA;
               				 print $socket "ERR Argument Error.\n";
               		 return;

			}
	}

     if($proto eq 'tcp')
        {
                 if($type eq 'den_1001')
                        {
                                push @rrdargs, "DEF:Flow${proto}_${type}_0=$rrdfile:src7:AVERAGE";
                        }elsif($type eq 'den_1002')
                        {
                                push @rrdargs, "DEF:Flow${proto}_${type}_1=$rrdfile:src8:AVERAGE";

                        }elsif($type eq 'den_1003')
                        {
                                push @rrdargs, "DEF:Flow${proto}_${type}_2=$rrdfile:src9:AVERAGE";
                        }elsif($type eq 'den_1004')
                        {
                                push @rrdargs, "DEF:Flow${proto}_${type}_3=$rrdfile:src10:AVERAGE";

                        }else
                        {
                                syslog('debug', "type dint match  ");
                                         print $socket $EODATA;
                                         print $socket "ERR Argument Error.\n";
                         return;

                        }
        }

     if($proto eq 'icmp')
        {
                 if($type eq 'den_1001')
                        {
                                push @rrdargs, "DEF:Flow${proto}_${type}_0=$rrdfile:src15:AVERAGE";
                        }elsif($type eq 'den_1002')
                        {
                                push @rrdargs, "DEF:Flow${proto}_${type}_1=$rrdfile:src16:AVERAGE";

                        }elsif($type eq 'den_1003')
                        {
                                push @rrdargs, "DEF:Flow${proto}_${type}_2=$rrdfile:src17:AVERAGE";
                        }else
                        {
                                syslog('debug', "type dint match  ");
                                         print $socket $EODATA;
                                         print $socket "ERR Argument Error.\n";
                         return;

                        }
        }

        push @rrdargs, "--start",  "$tstart";
        push @rrdargs, "--end",    "$tend";
        push @rrdargs, "--title",  "$datestr - $title" unless $light;
        push @rrdargs, "--vertical-label", "$title"  unless $light;

        # lin or log graph?
        push @rrdargs, "--logarithmic" if $logscale;
	if ( $light ) {
                push @rrdargs, "-w";
                push @rrdargs, "288";
                push @rrdargs, "-h";
                push @rrdargs, "150";
                push @rrdargs, "--no-legend";   # no legend in small pictures
        } else {
                push @rrdargs, "-w";
                push @rrdargs, "576";
                push @rrdargs, "-h";
                push @rrdargs, "300";
        }

	if($type eq 'den_1001')
	{
		 push @rrdargs, "LINE2:Flow${proto}_${type}_0$colour[8]:Flow ${type}";

	}elsif($type eq 'den_1002')
	{
		 push @rrdargs, "LINE2:Flow${proto}_${type}_1$colour[0]:Flow ${type}";

	}elsif($type eq 'den_1003')
	{
		 push @rrdargs, "LINE2:Flow${proto}_${type}_2$colour[1]:Flow ${type}";
	}elsif($type eq 'den_1004')
	{
		 push @rrdargs, "LINE2:Flow${proto}_${type}_3$colour[3]:Flow ${type}";

	}else
	{
		syslog('debug', "type dint match  ");
                print $socket $EODATA;
                print $socket "ERR Argument Error.\n";
                return;
	}

	my($averages,$xsize,$ysize) = RRDs::graph( @rrdargs );

	my $ERROR;
        if ($ERROR = RRDs::error) {
                print "ERROR: $ERROR\n";
        }
	syslog('debug', "rrd error is $ERROR");

} # End of Get-Graph



sub nsel_execute {
        my $command = shift;

        syslog('debug', $command);

        my $ret = system($command);
        if ( $ret == - 1 ) {
                syslog('err', "Failed to execute nsel: $!\n");
        } elsif ($ret & 127) {
                syslog('err', "nsel died with signal %d, %s coredump\n", ($ret & 127),  ($ret & 128) ? 'with' : 'without');
        } else {
                syslog('debug', "nsel exited with value %d\n", $ret >> 8);
        }

} # End of nftrack_execute



sub RunNselD {
        my $socket      = shift;
        my $opts        = shift;
	my $tstart;
        my $tend;
	my $dumpType;
	my $limitFlows;
	syslog('debug',"RunNselD : Profiel Read Start \n");
        my ($profile, $profilegroup);
	$profile = 'live';
	$profilegroup ='.';
        my $profilepath = NfProfile::ProfilePath($profile,$profilegroup);	
	syslog('debug',"Profile Path --> $profilepath \n");
	my %profileinfo  = NfProfile::ReadProfile($profile);
	my $all_sources = join ":",keys %{$profileinfo{'channel'}};
	syslog('debug',"Sources ->  $all_sources \n");
	
	my $netflow_sources = "$NfConf::PROFILEDATADIR/$profilepath/$all_sources";
	syslog('debug',"RunNselD : Profiel Read End\n");

	# get all arguments:o
        # Example:o
        # tstart tend 
        # 1116495000 1116581400

  	if ( !exists $$opts{'tstart'} ) {
	 	print $socket $EODATA;
                print $socket "ERR Missing Start Time.\n";
		syslog('debug', "start time missing ");
		return;
        } else {
                $tstart = $$opts{'tstart'};
        }

  	if ( !exists $$opts{'tend'} ) {
	 	print $socket $EODATA;
                print $socket "ERR Missing End Time.\n";
		syslog('debug', "end time missing ");
		return;
        } else {
                $tend = $$opts{'tend'};
        }
	$dumpType = $$opts{'dumpType'};
	$limitFlows = $$opts{'limitFlows'};
	syslog('debug', "dump type -->  $dumpType\n");

	my $subdirs1 = NfSen::SubdirHierarchy($tstart);
	my $subdirs2 = NfSen::SubdirHierarchy($tend);


	syslog('debug',"tstart --> $tstart, tend --> $tend\n");
	my $tStartString = NfSen::UNIX2ISO($tstart);
	my $tEndString = NfSen::UNIX2ISO($tend);
	my $source;

	foreach $source (keys %{$profileinfo{'channel'}}) 
	{
		syslog('debug', "source --> $source\n");
	 	my $args = "-d $PORTSDBDIR  -R $NfConf::PROFILEDATADIR/$profilepath/$source/$subdirs1/nfcapd.$tStartString:$subdirs2/nfcapd.$tEndString  -s 0 -l $dumpType -c $limitFlows";
	syslog('debug', "Arguments : $args");
	my @lines;
        print $socket ".run nselD $args \n";
        printf $socket "arg=$args\n";

         my $pid = open(NSELD, ""$NfConf::PREFIX/nseld $args  2>&1|");
        if(!$pid)
        {
                my $err = "ERR nseld run error:$!\n";
                print $socket $EODATA;
                printf $socket $err;
                return;
        }
        print $socket ".pid: $pid\n";

        while(<NSELD>) {
          printf $socket "_nseld=$_\n";

        }
        my $nseld_exit=0;
        if(!close NSELD) {
                $nseld_exit = $?;
                my $exit_value = $nseld_exit >> 8;
                my $signal_num = $nseld_exit &127;
                my $dumped_core = $nseld_exit & 128;
                syslog('err', "Run nseld failed: Exit: $exit_value, Signal: $signal_num, Coredump: $dumped_core");
        }
         print  $socket "exit=$nseld_exit\n";
        print $socket $EODATA;
        print $socket "OK command completed.\n";
	syslog('debug', "Run NselID exited");
	
} #end of foreach



}

#
# Periodic function
#   input:  hash reference including the items:
#           'profile'       profile name
#           'profilegroup'  profile group
#           'timeslot'      time of slot to process: Format yyyymmddHHMM e.g. 200503031200
#  Logic of this function
#  As part of nsel RRD updation, every 5 mins this function is called we update RRDB with nsel record
#  then we display the ouput on the console which will be piped to feed into the socket desc
sub run {
    my $argref       = shift;

    my $profile      = $$argref{'profile'};
    my $profilegroup = $$argref{'profilegroup'};
    my $timeslot     = $$argref{'timeslot'};

	syslog('debug', "NselTracker run: Profile: $profile, Time: $timeslot");
   	my %profileinfo  = NfProfile::ReadProfile($profile);
        my $netflow_sources = "$PROFILEDATADIR/$profile/$profileinfo{'sourcelist'}";

        # process all sources of this profile at once
        my $command = "$nselD -M $netflow_sources -r nfcapd.$timeslot -d $PORTSDBDIR -A -t $timeslot -l 1 -s 1 -w /data/nfsen/nsel/nsel_stat.txt";
        nsel_execute($command);

	syslog('debug', "NselTracker run: Done.");

} # End of run

sub Init {
	syslog("info", "NselD : Init");

	# Init some vars
	$nselD  = "$NfConf::PREFIX/nselD";
	$PROFILEDATADIR = "$NfConf::PROFILEDATADIR";

	return 1;
}

sub Cleanup {
	syslog("info", "NselTracker Cleanup");
	# not used here
}

1;
