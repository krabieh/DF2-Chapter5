/*
 *  nftrack_stat.h: Maintain tinmestamp and stats for different
 *                counters needed for NSELTracker
 *                This file is taken from PortTracker plugin
 *                source code.Original author of the file
 *                is peter.
 *  $Author: peter , Suhas $
 *
 *  $Id: nftrack_stat.c 01 2008-07-12 09:13:12Z Suhas$
 *
 *  $LastChangedRevision: 01 $
 *
 *
 */


//Stats for per protocol based summary for each of the denied reason
typedef struct data_element_s {
   uint64_t type[4]; // for 4 denied reasons;
}data_element;

// Stats for summary of the counters - open , completed , denied and more (in future)
typedef struct data_row_summary_s
{
    uint64_t type[7];
}data_row_summary;

//Stats indexes per protocol.

typedef struct data_row_s {
	data_element	proto[3];	// 0 - tcp 1 - udp 1 - icmp
} data_row;


// to be used as index
enum { tcp = 0, udp, icmp };
enum {openF=0, complete, denied, denied_1001, denied_1002,denied_1003,denied_1004};


int InitStat(char *path);

int CloseStat(void);

int InitStatFile(time_t when, int av_num);

data_row_summary *GetStat(void);


void Generate_TopN(data_row *row, int n, int scale, time_t when, int output_mode, char *wfile);
void GenerateDump(data_row_summary *rec, char *wfile);

int UpdateStatNsel(data_row_summary *row, time_t when);

