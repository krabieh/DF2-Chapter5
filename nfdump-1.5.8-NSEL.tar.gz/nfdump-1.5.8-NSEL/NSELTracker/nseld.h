
#define BuffNumRecords	1024

/* 
 * Offset definitions for filter engine. Offsets must agree with the defined
 * flow record definition data_block_record_t in nffile.h
 */

#include "config.h"


