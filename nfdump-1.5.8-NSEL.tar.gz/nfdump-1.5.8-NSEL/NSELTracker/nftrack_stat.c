/*
 *  This code is made available as part of BSD Lincense
 *  Please refer to BSDLicense.txt for more information
 *
 *  nftrack_stat: Maitain tinmestamp and stats for different 
 *                counters needed for NSELTracker 
 *                This file is taken from PortTracker plugin  
 *                source code.Original author of the file
 *                is peter.
 *                (peter.haag@switch.ch)
 *  $Author: Suhas$
 *
 *  $Id: nseld.c 02 2008-07-24 12:00:00Z Suhas$
 *
 *  $LastChangedRevision: 01 $
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <syslog.h>
#include "config.h"

#ifdef HAVE_STDINT_H
#include <stdint.h>
#endif

#include "nftrack_stat.h"
#include "nsel_rrd.h"


#define NUMENTRIES 1
#define STATFILE "nseld.stat"


typedef struct stat_header_s {
	uint16_t	version;
	int			av_num;
	time_t		last;
} stat_header_t;


static stat_header_t	stat_header;
static data_row_summary         *stat_record;
static char				statfile[1024];
static char				dbpath[1024];
static int				dirty;

/* prototypes */
static void ReadStat(void);

/* Function to verift the dapath and stat file path */

int InitStat(char *path) {
int len;
	stat_header.version = 0;
	stat_record = NULL;

	len = snprintf(dbpath, 1024, "%s", path);
	len = snprintf(statfile, 1024, "%s/%s", path, STATFILE);
	if ( len >= 1024 ) {
		fprintf(stderr, "String overflow: statfile name\n");
		statfile[0] = 0;
		return 0;
	}
	dirty = 0;

	return 1;

} // End of InitStat

/* Create Stat file at dbpath with
 * header and data_row_summary as 
 * its single record
 */

int InitStatFile(time_t when, int av_num) {
ssize_t	num;
int		fd;

	if ( statfile[0] == 0 )
		return 0;

	stat_record = (data_row_summary *)calloc(NUMENTRIES, sizeof(data_row_summary));
	if ( !stat_record ) {
		fprintf(stderr, "Can't allocate stat buffer:  %s\n", strerror(errno));
		return 0;
	}

	memset((void *)stat_record, 0, NUMENTRIES* sizeof(data_row_summary));
	
	fd = open(statfile, O_CREAT | O_RDWR | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH );
	if ( fd < 0 ) {
		fprintf(stderr, "Can't open stat file '%s': %s\n", statfile, strerror(errno));
		free(stat_record);
		return 0;
	}
	stat_header.version = 1;
	stat_header.av_num	= av_num;
	stat_header.last	= when;

	syslog(LOG_INFO,": InitStatFile: when is set to %d , %s ", when, ctime(&when));
	num = write(fd, &stat_header, sizeof(stat_header));
	num = write(fd, stat_record, NUMENTRIES* sizeof(data_row_summary));
	if ( num < 0 ) {
		fprintf(stderr, "Can't write stat record: %s\n", strerror(errno));
		stat_header.version = 0;
		free(stat_record);
		close(fd);
		return 0;
	}
	
	
	close(fd);

	return 1;

} // End of InitStatFile

data_row_summary *GetStat(void) {

	if ( !stat_record ) 
		ReadStat();
	return stat_record;

} // End of GetStat

/* Function  writes the last  updated timestamp
 *  which is used by FrontEnd for the 
 * graphs time inputs
 */  

 
void GenerateDump(data_row_summary *rec, char *wfile)
{
FILE *wfd;
time_t when;

  wfd = NULL;
  if(wfile)
  {
	wfd = fopen(wfile,"w");
	if(wfd == NULL) {
		perror("cant open output file for writting");
		return;
	}

  }
	syslog(LOG_INFO,"\n In gen dump .. updating time to %s", ctime(&stat_header.last));
	when = stat_header.last;
	fprintf(wfd,"%d\n",(int)when);
	fclose(wfd);	
} // End of Generate Dump

/* function to write the updated stat_record to the file
 * Imp in the sense for the RRDB to get the last updated time
 * timestamp .. Be Karepull for being called this
 */

int CloseStat(void) {
int 	fd;
ssize_t	num;

	if ( statfile[0] == 0 || !dirty )
		return 1;

	fd = open(statfile, O_CREAT | O_RDWR | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH );
	if ( fd < 0 ) {
		fprintf(stderr, "Can't open stat file '%s': %s\n", statfile, strerror(errno));
		return 0;
	}

	num = write(fd, (void *)&stat_header, sizeof(stat_header));
	if ( num < 0 ) {
		fprintf(stderr, "Can't write stat record: %s\n", strerror(errno));
		close(fd);
		return 0;
	}

	num = write(fd, stat_record, NUMENTRIES* sizeof(data_row_summary));
	if ( num < 0 ) {
		fprintf(stderr, "Can't read stat record: %s\n", strerror(errno));
		return 0;
	}

	free(stat_record);
	stat_record = NULL;
	stat_header.version = 0;
	close(fd);
	
	return 1;

} // End of CloseStat

static void ReadStat(void) {
int 	fd;
ssize_t	num;
                syslog(LOG_INFO, "in readstat()");
	if ( statfile[0] == 0 )
		return;

	stat_record = (data_row_summary *)calloc(NUMENTRIES, sizeof(data_row_summary));
	if ( !stat_record ) {
		fprintf(stderr, "Can't allocate stat buffer:  %s\n", strerror(errno));
		return;
	}
	//syslog(LOG_INFO,"Suhas: ReadStat: Opening statfile %s", statfile);
	fd = open(statfile, O_RDONLY );
	if ( fd < 0 ) {
		fprintf(stderr, "Can't open stat file '%s': %s\n", statfile, strerror(errno));
		free(stat_record);
		stat_record = NULL;
		return;
	}

	num = read(fd, (void *)&stat_header, sizeof(stat_header));
	if ( num < 0 ) {
		fprintf(stderr, "Can't read stat record: %s\n", strerror(errno));
		free(stat_record);
		stat_record = NULL;
		close(fd);
		return;
	}
	//syslog(LOG_INFO, " ReadStat : header version is %d", stat_header.version);
	//syslog(LOG_INFO, " ReadStat : when is %d , %s", stat_header.last, ctime(&stat_header.last));

	if ( stat_header.version != 1 ) {
		fprintf(stderr, "Version error stat file. Found version: %d expected: 1\n", stat_header.version);
		free(stat_record);
		stat_record = NULL;
		stat_header.version = 0;
		close(fd);
		return;
	}

	num = read(fd, stat_record, NUMENTRIES* sizeof(data_row_summary));
	if ( num < 0 ) {
		fprintf(stderr, "Can't read stat record: %s\n", strerror(errno));
		free(stat_record);
		stat_record = NULL;
		stat_header.version = 0;
		close(fd);
	}
	
} // End of ReadStat


/* Function that updates the stat_record based on
 * last updated stat instance
 */

int UpdateStatNsel(data_row_summary *row, time_t when) {
data_row_summary        *oldrow;
int t;
time_t  tslot;

        if ( !stat_record ) {
		syslog(LOG_INFO, "updatestatnsel: callin readsta()");
                ReadStat();
                if ( !stat_record )
		{
			syslog(LOG_INFO,"STAT ILLA ");
                        return 0;
		}
        }

	 for (t=0; t<7; t++) {
                 stat_record->type[t]+= row->type[t];
             } 

   	if ( (when - stat_header.last ) > 1800 ) {
                // last update too far away
                // pretend last update was max half an hour ago, otherwise it takes too long
                stat_header.last = when - 300;
		
        }
        // Subtract old slots
        for ( tslot = stat_header.last - (stat_header.av_num * 300); tslot < when - (stat_header.av_num * 300); tslot += 300 ) {
                oldrow = RRD_GetDataRow(dbpath, tslot);
		  if(!oldrow)
		{
			syslog(LOG_INFO,"\n Old row is null .. exiting ");
			return 0;
			exit(255);
		}
                    for (t=0; t<7; t++) {
                         stat_record->type[t] -= oldrow->type[t];
                     }
             }
        stat_header.last = when;
        dirty = 1;
        return 1;


}


