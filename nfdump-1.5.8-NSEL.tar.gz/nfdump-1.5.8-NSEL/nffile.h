/*
 *  This file is part of the nfdump project.
 *
 *  Copyright (c) 2004, SWITCH - Teleinformatikdienste fuer Lehre und Forschung
 *  All rights reserved.
 *  
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions are met:
 *  
 *   * Redistributions of source code must retain the above copyright notice, 
 *	 this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above copyright notice, 
 *	 this list of conditions and the following disclaimer in the documentation 
 *	 and/or other materials provided with the distribution.
 *   * Neither the name of SWITCH nor the names of its contributors may be 
 *	 used to endorse or promote products derived from this software without 
 *	 specific prior written permission.
 *  
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE 
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE 
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE 
 *  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 *  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
 *  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS 
 *  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
 *  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
 *  POSSIBILITY OF SUCH DAMAGE.
 *  
 *  $Author: peter $
 *
 *  $Id: nffile.h 98 2008-06-01 09:50:02Z suhas$
 *
 *  $LastChangedRevision: 98 $
 *	
 * * $Modification History
 * Author		  : Suhas Nandakumar
 * Details		 : Added Support CISCO Specific NSEL Fields
 * Date			: Jun 1 2008 - Jul 15 2008
 *
 *  $LastChangedRevision: 98 $
 */

#define IdentLen	128
#define IdentNone	"none"

#define NF_EOF		 	 0
#define NF_ERROR		-1
#define NF_CORRUPT		-2


/*
 *
 * 
 */
typedef struct file_header_s {
	uint16_t	magic;				// magic to recognize endian type
	uint16_t	version;			// version of binary file layout, incl. magic
#define NUM_FLAGS		1
#define FLAG_COMPRESSED 0x1
	uint32_t	flags;				/*
										0x1 File is compressed with LZO1X-1 compression
									 */
	uint32_t	NumBlocks;			// number of blocks in file
	char		ident[IdentLen];	// identifies this data
} file_header_t;

typedef struct stat_record_s {
	// overall stat
	uint64_t	numflows;
	uint64_t	numbytes;
	uint64_t	numpackets;
	// flow stat
	uint64_t	numflows_tcp;
	uint64_t	numflows_udp;
	uint64_t	numflows_icmp;
	uint64_t	numflows_other;
	// bytes stat
	uint64_t	numbytes_tcp;
	uint64_t	numbytes_udp;
	uint64_t	numbytes_icmp;
	uint64_t	numbytes_other;
	// packet stat
	uint64_t	numpackets_tcp;
	uint64_t	numpackets_udp;
	uint64_t	numpackets_icmp;
	uint64_t	numpackets_other;
	// time window
	uint32_t	first_seen;
	uint32_t	last_seen;
	uint16_t	msec_first;
	uint16_t	msec_last;
	// other
	uint32_t	sequence_failure;
} stat_record_t;

typedef struct data_block_header_s {
	uint32_t	NumBlocks;		// number of data records in data block
	uint32_t	size;			// number of this block in bytes without this header
	uint16_t	id;				// flags for this block
	uint16_t	pad;
} data_block_header_t;

#define DATA_BLOCK_TYPE_1	1

typedef struct common_record_s {
	// the head of each data record
	uint32_t	flags;
	uint16_t	size;
	uint16_t	mark;
	uint16_t	msec_first;
	uint16_t	msec_last;
	uint32_t	first;
	uint32_t	last;

	uint8_t		dir;
	uint8_t		tcp_flags;
	uint8_t		prot;
	uint8_t		tos;
	uint16_t	input;
	uint16_t	output;
	uint16_t	srcport;
	uint16_t	dstport;
	uint16_t	srcas;
	uint16_t	dstas;
	uint8_t		data[4];	// .. more data below
} common_record_t;

#define BYTE_OFFSET_first	   12

// number of netflow elements in data_block_record_t: first .. dOctets
// 18 std v9 + 17 NSEL
#define NumElements 		35


typedef struct ipv4_block_s {
#ifdef WORDS_BIGENDIAN
	uint32_t	fill1[3];
	uint32_t	srcaddr;
	uint32_t	fill2[3];
	uint32_t	dstaddr;
#else
	uint32_t	fill1[2];
	uint32_t	srcaddr;
	uint32_t	fill2;
	uint32_t	fill3[2];
	uint32_t	dstaddr;
	uint32_t	fill4;
#endif
} ipv4_block_t;

typedef struct ipv6_block_s {
	uint64_t	srcaddr[2];
	uint64_t	dstaddr[2];
} ipv6_block_t;

typedef struct ip_block_s {
	union {
		ipv4_block_t	_v4;
		ipv6_block_t	_v6;
	} ip_union;
#define v4 ip_union._v4
#define v6 ip_union._v6
	uint8_t		data[4];	// .. more data below
} ip_block_t;

typedef struct value32_s {
	uint32_t	val;
	uint8_t		data[4];	// .. more data below
} value32_t;

typedef struct value64_s {
	union val_s {
		uint64_t	val64;
		uint32_t	val32[2];
	} val;
	uint8_t		data[4];	// .. more data below
} value64_t;


/* NSEL/ASA specific records */
typedef struct nsel_common {
	uint8_t	 	nf9_fw_evt;
	uint8_t	 	fill;
	uint16_t	nf9_fw_ext_evt;
	uint32_t	nf9_flow_bytes;
	uint64_t	nf_evt_msec;
	uint8_t		data[4];
} nsel_common_t;

// 44 + 20 = 64bytes
// ID 256:  IPv4 flow creation event with common username size (20 chars)
typedef struct flow_creat_256 {
	uint32_t 	 nf_conn_id;
	uint8_t  	 nf_icmp_type;
	uint8_t  	 nf_icmp_code;
	uint16_t 	 fill;

	//xlate info
	uint32_t	 nf_ingress_acl[3];
	uint32_t	 nf_egress_acl[3];
	ipv4_block_t xlate_ip;
	uint16_t 	 xlate_src_port;
	uint16_t 	 xlate_dst_port;
	uint8_t  	 nf_user_name[20];

} fc_256;

// 44 + 68 = 112bytes
// ID 257:  IPv4 flow creation event with maximum username size (65 chars)
typedef struct flow_creat_257 {
	uint32_t 	 nf_conn_id;
	uint8_t  	 nf_icmp_type;
	uint8_t  	 nf_icmp_code;
	uint16_t 	 _fill;

	//xlate info
	uint32_t	 nf_ingress_acl[3];
	uint32_t	 nf_egress_acl[3];
	ipv4_block_t xlate_ip;
	uint16_t 	 xlate_src_port;
	uint16_t 	 xlate_dst_port;
	uint8_t  	 nf_user_name[65+3];	// add 3 extra fill bytes for 32bit alignment
} fc_257;

// 258: IPv6 flow creation with common username size
// 32 + 20 = 52bytes
typedef struct flow_creat_258 {
	uint32_t	nf_conn_id;
	uint8_t  	nf_icmp_type;
	uint8_t		nf_icmp_code;
	uint16_t	_fill;

	uint32_t	nf_ingress_acl[3];
	uint32_t	nf_egress_acl[3];
	uint8_t  	nf_user_name[20];
} fc_258;

// 259: IPv6 flow creation with maximum username size
// 32 + 68 = 104bytes
typedef struct flow_creat_259 {
	uint32_t 	nf_conn_id;
	uint8_t  	nf_icmp_type;
	uint8_t  	nf_icmp_code;
	uint16_t	_fill;

	uint32_t	nf_ingress_acl[3];
	uint32_t	nf_egress_acl[3];
	uint8_t  	nf_user_name[65+3];		// add 3 extra fill bytes for 32bit alignment
} fc_259;

// 260: IPv4 flow denied
// 44bytes
typedef struct flow_den_260 {
	uint32_t	 _fill2;
	uint8_t  	 nf_icmp_type;
	uint8_t  	 nf_icmp_code;
	uint16_t	 _fill;
	//xlate info
	uint32_t	 nf_ingress_acl[3];
	uint32_t	 nf_egress_acl[3];
	ipv4_block_t xlate_ip;
	uint16_t 	 xlate_src_port;
	uint16_t 	 xlate_dst_port;
} fd_260;

//261: IPv4 flow denied, no xlate fields present
// 32bytes
typedef struct flow_den_261 {
	uint32_t	_fill2;
	uint8_t  	nf_icmp_type;
	uint8_t  	nf_icmp_code;
	uint16_t	_fill;
	uint32_t	nf_ingress_acl[3];
	uint32_t	nf_egress_acl[3];
} fd_261;

// 262: IPv6 flow denied
// 32bytes
typedef struct flow_den_262 {
	uint32_t	_fill2;
	uint8_t  	nf_icmp_type;
	uint8_t  	nf_icmp_code;
	uint16_t	_fill;
	uint32_t	nf_ingress_acl[3];
	uint32_t	nf_egress_acl[3];
} fd_262;

// 263: IPv4 flow terminated
// 20bytes
typedef struct flow_term_263 {
	uint32_t 	 nf_conn_id;
	uint8_t  	 nf_icmp_type;
	uint8_t  	 nf_icmp_code;
	uint16_t	_fill;
	//xlate info
	ipv4_block_t xlate_ip;
	uint16_t 	 xlate_src_port;
	uint16_t 	 xlate_dst_port;
} ft_263;

// 264: IPv6 flow terminated
// 8bytes
typedef struct flow_term_264 {
	uint32_t nf_conn_id;
	uint8_t  nf_icmp_type;
	uint8_t  nf_icmp_code;
	uint16_t _fill;
} ft_264;


/* Master record with NSEL SUPPORT */
/* the master record contains all possible records unpacked */
typedef struct master_record_s {
	// common information from all netflow versions
	//						   	// interpreted as uint64_t[]
	uint32_t	flags;		   	// index 0  0xffff'ffff'0000'0000
	uint16_t	size;			// index 0  0x0000'0000'ffff'0000
	uint16_t	mark;			// index 0  0x0000'0000'0000'ffff
	uint16_t	msec_first;	  	// index 1  0xffff'0000'0000'0000
	uint16_t	msec_last;	   	// index 1  0x0000'ffff'0000'0000
	uint32_t	first;		   	// index 1  0x0000'0000'ffff'ffff
	uint32_t	last;			// index 2  0xffff'ffff'0000'0000
	uint8_t	 	dir;			// index 2  0x0000'0000'ff00'0000
	uint8_t	 	tcp_flags;	   	// index 2  0x0000'0000'00ff'0000
	uint8_t	 	prot;			// index 2  0x0000'0000'0000'ff00
	uint8_t	 	tos;			// index 2  0x0000'0000'0000'00ff
	uint16_t	input;		   	// index 3  0xffff'0000'0000'0000
	uint16_t	output;		  	// index 3  0x0000'ffff'0000'0000
	uint16_t	srcport;		// index 3  0x0000'0000'ffff'0000
	uint16_t	dstport;		// index 3  0x0000'0000'0000'ffff
	uint16_t	srcas;		   	// index 4  0xffff'0000'0000'0000
	uint16_t	dstas;		   	// index 4  0x0000'ffff'0000'0000
	uint32_t	nsel_flags;		// index 4  0x0000'0000'ffff'ffff

	// IP address block
	union {					   
		ipv4_block_t	_v4;	// srcaddr	  	index 6 0x0000'0000'ffff'ffff
								// dstaddr	  	index 8 0x0000'0000'ffff'ffff
		ipv6_block_t	_v6;	// srcaddr[0-1] index 5 0xffff'ffff'ffff'ffff
								// srcaddr[2-3] index 6 0xffff'ffff'ffff'ffff
								// dstaddr[0-1] index 7 0xffff'ffff'ffff'ffff
								// dstaddr[2-3] index 8 0xffff'ffff'ffff'ffff
	} ip_union;

	// counter block - expanded to 8 bytes
	uint64_t	dPkts;		  	// index 9  0xffff'ffff'ffff'ffff
	uint64_t	dOctets;		// index 10 0xffff'ffff'ffff'ffff

	// NSEL data
	uint8_t	 	nf9_fw_evt;	 	// index 11 0xff00'0000'0000'0000
	uint8_t	 	_fill1;	   		// index 11 0x00ff'0000'0000'0000'
	uint16_t	nf9_fw_ext_evt; // index 11 0x0000'ffff'0000'0000
	uint32_t	nf9_flow_bytes; // index 11	0x0000'0000'ffff'ffff
	uint64_t	nf_evt_msec;	// index 12 0xffff'ffff'ffff'ffff			  

 	// for 
	uint32_t 	 nf_conn_id;		 // index 13 0xffff'ffff'0000'0000
	uint8_t  	 nf_icmp_type;		 // index 13 0x0000'0000'ff00'0000
	uint8_t  	 nf_icmp_code;		 // index 13 0x0000'0000'00ff'0000
	uint16_t 	 _fill2;			 // index 13 0x0000'0000'0000'ffff

	// xlate info					
	uint32_t	 nf_ingress_acl[3];	 // index 14 0xffff'ffff'0000'0000 [2] -> incl index 15
	uint32_t	 nf_egress_acl[3];	 // index 15 0x0000'0000'ffff'ffff [2] -> incl index 16
	ipv4_block_t xlate_ip;			 // srcaddr	index 17 0x0000'0000'ffff'ffff
									 // dstaddr index 19 0x0000'0000'ffff'ffff
	uint16_t 	 xlate_src_port;	 // index 21 0xffff'0000'0000'0000
	uint16_t 	 xlate_dst_port;	 // index 21 0x0000'ffff'0000'0000
	uint8_t  	 nf_user_name[65+3]; // index 21 0x0000'0000'ffff'ffff

} master_record_t;

typedef struct type_mask_s {
	union {
		uint8_t		val8[8];
		uint16_t	val16[4];
		uint32_t	val32[2];
		uint64_t	val64;
	} val;
} type_mask_t;


#define AnyMask	  0xffffffffffffffffLL

#ifdef WORDS_BIGENDIAN

#define OffsetRecordFlags	0
#define MaskRecordFlags	  	0xffffffff00000000LL
#define ShiftRecordFlags	32

#define OffsetDir		2
#define MaskDir			0x00000000ff000000LL
#define ShiftDir		24

#define OffsetFlags	 	2
#define MaskFlags	   	0x0000000000ff0000LL
#define ShiftFlags	  	16

#define OffsetProto	 	2
#define MaskProto	   	0x000000000000ff00LL
#define ShiftProto	  	8

#define OffsetTos		2
#define MaskTos			0x00000000000000ffLL
#define ShiftTos		0

#define OffsetInOut	 	3
#define MaskInput		0xffff000000000000LL
#define MaskOutput		0x0000ffff00000000LL
#define ShiftInput		48
#define ShiftOutput	 	32   

#define OffsetPort		3
#define MaskDstPort	 	0x000000000000ffffLL
#define MaskSrcPort	 	0x00000000ffff0000LL
#define ShiftDstPort	0
#define ShiftSrcPort	16
#define MaskICMPtype	0x000000000000ff00LL
#define MaskICMPcode	0x00000000000000ffLL
#define ShiftICMPcode	0
#define ShiftICMPtype	8

#define OffsetAS		4
#define MaskSrcAS		0xffff000000000000LL
#define MaskDstAS		0x0000ffff00000000LL
#define ShiftSrcAS		48
#define ShiftDstAS		32

#define OffsetNFlags	4
#define MaskNFlags	  	0x00000000ffffffffLL
#define ShiftNFlags		0

#define OffsetSrcIPv4	6
#define MaskSrcIPv4	  	0x00000000ffffffffLL
#define ShiftSrcIPv4	0

#define OffsetDstIPv4	8
#define MaskDstIPv4	  	0x00000000ffffffffLL
#define ShiftDstIPv4	0   

#define OffsetSrcIPv6a	5
#define OffsetSrcIPv6b	6
#define OffsetDstIPv6a	7
#define OffsetDstIPv6b	8
#define MaskIPv6		0xffffffffffffffffLL
#define ShiftIPv6		0

#define OffsetPackets	9
#define MaskPackets	  	0xffffffffffffffffLL
#define ShiftPackets	0

#define OffsetBytes	 	10
#define MaskBytes		0xffffffffffffffffLL
#define ShiftBytes		0

#define OffsetEvent		11
#define MaskEvent		0xff00000000000000LL
#define ShiftEvent		52

#define OffsetExtEvent	11
#define MaskExtEvent	0x0000ffff00000000LL
#define ShiftExtEvent	32

#define OffsetFlowBytes	11
#define MaskFlowBytes	0x00000000ffffffffLL
#define ShiftFlowBytes	0

// fc_256 related masks
// ingress acl related mask
#define OffsetIngressAclId	14
#define MaskIngressAclId	0xffffffff00000000LL
#define ShiftIngressAclId	32
#define OffsetIngressAceId	14
#define MaskIngressAceId	0x00000000ffffffffLL
#define ShiftIngressAceId	0
#define OffsetIngressGrpId	15
#define MaskIngressGrpId	0xffffffff00000000LL
#define ShiftIngressGrpId	32

// egress acl related mask
#define OffsetEgressAclId	15
#define MaskEgressAclId		0x00000000ffffffffLL
#define ShiftEgressAclId	0
#define OffsetEgressAceId	16
#define MaskEgressAceId		0xffffffff00000000LL
#define ShiftEgressAceId	32
#define OffsetEgressGrpId	16
#define MaskEgressGrpId		0x00000000ffffffffLL
#define ShiftEgressGrpId	0

#define OffsetXlateSrcIPa	17
#define OffsetXlateSrcIPb	18
#define OffsetXlateDstIPa	19
#define OffsetXlateDstIPb	20
#define MaskXlateIP			0xffffffffffffffffLL
#define ShitXlateIP			0

#define OffsetXlateSrcProt  21
#define MaskXlateSrcProt	0xffff000000000000LL
#define ShiftXlateSrcPort   48

#define OffsetXlateDstPort	21
#define MaskXlateDstPort	0x0000ffff00000000LL
#define ShiftXlateDstPort	32

// user name mask
#define OffsetUserName		21
#define MaskUserName		0x00000000ffffffffLL
#define ShiftUserName		0

#else

#define OffsetRecordFlags	0
#define MaskRecordFlags	  	0x00000000ffffffffLL
#define ShiftRecordFlags	0

#define OffsetDir		2
#define MaskDir			0x000000ff00000000LL
#define ShiftDir		32

#define OffsetFlags	 	2
#define MaskFlags	   	0x0000ff0000000000LL
#define ShiftFlags	  	40

#define OffsetProto	 	2
#define MaskProto	   	0x00ff000000000000LL
#define ShiftProto	  	48

#define OffsetTos		2
#define MaskTos			0xff00000000000000LL
#define ShiftTos		56

#define OffsetInOut	 	3
#define MaskInput		0x000000000000ffffLL
#define MaskOutput		0x00000000ffff0000LL
#define ShiftInput		0
#define ShiftOutput	 	16

#define OffsetPort		3
#define MaskDstPort	 	0xffff000000000000LL
#define MaskSrcPort	 	0x0000ffff00000000LL
#define ShiftDstPort	48
#define ShiftSrcPort	32
#define MaskICMPtype	0xff00000000000000LL
#define MaskICMPcode	0x00ff000000000000LL
#define ShiftICMPcode	48
#define ShiftICMPtype	56

#define OffsetAS		4
#define MaskDstAS		0x00000000ffff0000LL
#define MaskSrcAS		0x000000000000ffffLL
#define ShiftSrcAS		0
#define ShiftDstAS		16

#define OffsetNFlags	4
#define MaskNFlags	  	0xffffffff00000000LL
#define ShiftNFlags		32

#define OffsetSrcIPv4	6
#define MaskSrcIPv4	  	0xffffffff00000000LL
#define ShiftSrcIPv4	32

#define OffsetDstIPv4	8
#define MaskDstIPv4	  	0xffffffff00000000LL
#define ShiftDstIPv4	32

#define OffsetSrcIPv6a	5
#define OffsetSrcIPv6b	6
#define OffsetDstIPv6a	7
#define OffsetDstIPv6b	8
#define MaskIPv6		0xffffffffffffffffLL
#define ShiftIPv6		0

#define OffsetPackets	9
#define MaskPackets	 	0xffffffffffffffffLL
#define ShiftPackets	0

#define OffsetBytes	 	10
#define MaskBytes		0xffffffffffffffffLL
#define ShiftBytes		0

#define OffsetEvent		11
#define MaskEvent		0x00000000000000ffLL
#define ShiftEvent		0

#define OffsetExtEvent	11
#define MaskExtEvent	0x00000000ffff0000LL
#define ShiftExtEvent	16

#define OffsetFlowBytes	11
#define MaskFlowBytes	0xffffffff00000000LL
#define ShiftFlowBytes	32

// fc_256 related masks
// ingress acl related mask
#define OffsetIngressAclId	14
#define MaskIngressAclId	0x00000000ffffffffLL
#define ShiftIngressAclId	0
#define OffsetIngressAceId	14
#define MaskIngressAceId	0xffffffff00000000LL
#define ShiftIngressAceId	32
#define OffsetIngressGrpId	15
#define MaskIngressGrpId	0x00000000ffffffffLL
#define ShiftIngressGrpId	0

// egress acl related mask
#define OffsetEgressAclId	15
#define MaskEgressAclId		0xffffffff00000000LL
#define ShiftEgressAclId	32
#define OffsetEgressAceId	16
#define MaskEgressAceId		0x00000000ffffffffLL
#define ShiftEgressAceId	0
#define OffsetEgressGrpId	16
#define MaskEgressGrpId		0xffffffff00000000LL
#define ShiftEgressGrpId	32

#define OffsetXlateSrcIPa	17
#define OffsetXlateSrcIPb	18
#define OffsetXlateDstIPa	19
#define OffsetXlateDstIPb	20
#define MaskXlateIP			0xffffffffffffffffLL
#define ShitXlateIP			0

#define OffsetXlateSrcProt  21
#define MaskXlateSrcProt	0x000000000000ffffLL
#define ShiftXlateSrcPort   0

#define OffsetXlateDstPort	21
#define MaskXlateDstPort	0x00000000ffff0000LL
#define ShiftXlateDstPort	16

// user name mask
#define OffsetUserName		21
#define MaskUserName		0xffffffff00000000LL
#define ShiftUserName		32

#endif

/*
 * flags:
 * bit  0:	0: IPv4				1: IPv6
 * bit  1:	0: 32bit dPkts		1: 64bit dPkts
 * bit  2:	0: 32bit dOctets	1: 64bit dOctets 
 * more to come ...
 *
 * bit 31:	reserved for future use. must be 0.
 */

#define FLAG_IPV6_ADDR	 1
#define FLAG_PKG_64		 2
#define FLAG_BYTES_64	 4
#define FLAG_NSEL_FLOW	16

// FLAGS FOR NSEL EVENTS
#define FLAG_FLOW_CREAT 		   1
#define FLAG_FLOW_CREAT_UMAX 	   2
#define FLAG_FLOW_CREAT_V6 		   4
#define FLAG_FLOW_CREAT_UMAX_V6    8
#define FLAG_FLOW_DENIED		  16
#define FLAG_FLOW_DENIED_NOXLATE  32
#define FLAG_FLOW_DENIED_V6		  64
#define FLAG_FLOW_TERM 			 128
#define FLAG_FLOW_TERM_V6		 256

#define MASK_CONN_ID  (FLAG_FLOW_CREAT + FLAG_FLOW_CREAT_UMAX + FLAG_FLOW_CREAT_V6 + FLAG_FLOW_CREAT_UMAX_V6 + FLAG_FLOW_TERM + FLAG_FLOW_TERM_V6)
#define MASK_ACLS     (FLAG_FLOW_CREAT + FLAG_FLOW_CREAT_UMAX + FLAG_FLOW_CREAT_V6 + FLAG_FLOW_CREAT_UMAX_V6 + FLAG_FLOW_DENIED + FLAG_FLOW_DENIED_NOXLATE + FLAG_FLOW_DENIED_V6)
#define MASK_XLATE	  (FLAG_FLOW_CREAT + FLAG_FLOW_CREAT_UMAX + FLAG_FLOW_DENIED + FLAG_FLOW_TERM)
#define MASK_USER     (FLAG_FLOW_CREAT + FLAG_FLOW_CREAT_V6)
#define MASK_USER_MAX (FLAG_FLOW_CREAT_UMAX + FLAG_FLOW_CREAT_UMAX_V6)
#define MASK_CREATE	  (FLAG_FLOW_CREAT + FLAG_FLOW_CREAT_UMAX + FLAG_FLOW_CREAT_V6 + FLAG_FLOW_CREAT_UMAX_V6)
#define MASK_TERM	  (FLAG_FLOW_TERM + FLAG_FLOW_TERM_V6) 
#define MASK_DENIED   (FLAG_FLOW_DENIED + FLAG_FLOW_DENIED_NOXLATE + FLAG_FLOW_DENIED_V6)

// nsel specific event constants
#define NSEL_256 256
#define NSEL_257 257
#define NSEL_258 258
#define NSEL_259 259
#define NSEL_260 260
#define NSEL_261 261
#define NSEL_262 262
#define NSEL_263 263
#define NSEL_264 264

/*
 * offset translation table
 * In netflow v9 values may have a different length, and may or may not be present.
 * The commmon information ( see data_block_record_t ) is expected to be present
 * unconditionally, and has a fixed size. IP addrs as well as counters for packets and
 * bytes are expexted to exist as well, but may be variable in size. Further information
 * may or may not be present, according the flags. See flags
 * To cope with this situation, the offset translation table gives the offset into an
 * uint32_t array at which offset the requested value start.
 *
 * index:
 *	 0:	dstip
 *				for IPv4 netflow v5/v7	10
 *	 1: dPkts
 * 				for IPv4 netflow v5/v7	11
 *	 2: dOctets
 * 				for IPv4 netflow v5/v7	12
 */


void SumStatRecords(stat_record_t *s1, stat_record_t *s2);

int OpenFile(char *filename, stat_record_t **stat_record, char **err);

int OpenNewFile(char *filename, char **err, int compressed);

int ChangeIdent(char *filename, char *Ident, char **err);

void PrintStat(stat_record_t *s);

void QueryFile(char *filename);

void CloseUpdateFile(int fd, stat_record_t *stat_record, uint32_t record_count, char *ident, int compressed, char **err );

int ReadBlock(int rfd, data_block_header_t *block_header, void *read_buff, char **err);

int WriteBlock(int wfd, data_block_header_t *block_header, int compress);

void UnCompressFile(char * filename);

char *GetIdent(void);

void ExpandRecord(common_record_t *input_record,master_record_t *output_record );

#ifdef COMPAT14

/*
 * compatibility code with data files - nfdump 1.4
 * This code will be removed some time.
 */

/* compat definitions */
typedef struct compat14_flow_header_s {
	uint16_t  version;
	uint16_t  count;
	uint32_t  SysUptime;
	uint32_t  unix_secs;
	uint32_t  unix_nsecs;
	uint32_t  flow_sequence;
	uint8_t   engine_type;
	uint8_t   engine_id;
	uint16_t  layout_version; /* binary layout version */
} compat14_flow_header_t;

typedef struct compat14_flow_record_s {
	uint32_t  srcaddr;
	uint32_t  dstaddr;
	uint32_t  nexthop;
	uint16_t  input;
	uint16_t  output;
	uint32_t  dPkts;
	uint32_t  dOctets;
	uint32_t  First;	  /* First seen timestamp in UNIX time format. msec offset at end of record */
	uint32_t  Last;	   /* Last seen timestamp in UNIX time format. msec offset at end of record */
	uint16_t  srcport;
	uint16_t  dstport;
	uint8_t   pad;	
	uint8_t   tcp_flags;
	uint8_t   prot;
	uint8_t   tos;
	uint16_t  src_as;
	uint16_t  dst_as;
	uint16_t  msec_first; /* msec offset from First */
	uint16_t  msec_last;	  /* msec offset from Last */
} comapt14_flow_record_t;

/* compat functions */
inline ssize_t	Compat14_ReadHeader(int fd, data_block_header_t *flow_header);

inline ssize_t Compat14_ReadRecords(int fd, void *buffer, data_block_header_t *flow_header);

#endif



