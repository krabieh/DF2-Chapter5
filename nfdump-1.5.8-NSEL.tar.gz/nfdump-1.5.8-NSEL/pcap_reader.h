
void setup_packethandler(char *fname, char *filter );

ssize_t NextPacket(void *buffer, size_t buffer_size);

