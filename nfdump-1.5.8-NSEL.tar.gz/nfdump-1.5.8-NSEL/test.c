#include <stdio.h>
typedef struct 
{
  short aa;
}a;

int main()
{
 a aa;
 printf("\n Size %d", sizeof(aa));
 return 0;  
};
